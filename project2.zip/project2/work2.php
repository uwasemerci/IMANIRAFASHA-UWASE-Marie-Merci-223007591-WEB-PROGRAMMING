<!DOCTYPE html>
<html>
<head>
    <title>Student Registration Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        
        .container {
            max-width: 700px;
            margin: 0 auto;
        }
        
        h1 {
            text-align: center;
            font-size: 18px;
            margin-bottom: 30px;
            font-weight: bold;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        td {
            padding: 10px;
            border: 0;
        }
        
        .label {
            font-weight: bold;
            width: 25%;
            text-align: left;
            vertical-align: top;
        }
        
        .input-field {
            width: 75%;
        }
        
        input[type="text"],
        input[type="email"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 5px;
            border: 1px solid #999;
            font-family: Arial, sans-serif;
            font-size: 12px;
            box-sizing: border-box;
        }
        
        textarea {
            resize: vertical;
            min-height: 60px;
        }
        
        .date-group {
            display: flex;
            gap: 10px;
        }
        
        .date-group select {
            flex: 1;
            width: 100%;
        }
        
        .button-container {
            text-align: center;
            margin-top: 15px;
            padding: 10px;
        }
        
        button {
            padding: 6px 25px;
            margin: 0 10px;
            cursor: pointer;
            background: #f0f0f0;
            border: 1px solid #999;
        }
        
        .qual-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .qual-table th {
            border: 0;
            padding: 6px;
            font-weight: bold;
            background: #f9f9f9;
            text-align: center;
            font-size: 12px;
        }
        
        .qual-table td {
            border: 0;
            padding: 6px;
            text-align: center;
        }
        
        .qual-table input {
            width: 100%;
            border: 1px solid #999;
            padding: 3px;
        }
        
        .checkbox-group {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .checkbox-group label {
            display: flex;
            align-items: center;
            gap: 5px;
            font-weight: normal;
        }
        
        input[type="checkbox"],
        input[type="radio"] {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['success']) && $_GET['success'] == '1') {
            echo 'Student registered successfully!';
        }
        ?>
        <h1>STUDENT REGISTRATION FORM</h1>
        
        <form method="post" action="process_registration.php">
            <table>
                <!-- FIRST NAME -->
                <tr>
                    <td class="label">FIRST NAME</td>
                    <td class="input-field"><input type="text" name="first_name" required></td>
                </tr>
                
                <!-- LAST NAME -->
                <tr>
                    <td class="label">LAST NAME</td>
                    <td class="input-field"><input type="text" name="last_name" required></td>
                </tr>
                
                <!-- DATE OF BIRTH -->
                <tr>
                    <td class="label">DATE OF BIRTH</td>
                    <td class="input-field">
                        <div class="date-group">
                            <select name="day" required>
                                <option value="">Day</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                                <option>21</option>
                                <option>22</option>
                                <option>23</option>
                                <option>24</option>
                                <option>25</option>
                                <option>26</option>
                                <option>27</option>
                                <option>28</option>
                                <option>29</option>
                                <option>30</option>
                                <option>31</option>
                            </select>
                            <select name="month" required>
                            <option value="">Month</option>
                            <option>January</option>
                            <option>February</option>
                            <option>March</option>
                            <option>April</option>
                            <option>May</option>
                            <option>June</option>
                            <option>July</option>
                            <option>August</option>
                            <option>September</option>
                            <option>October</option>
                            <option>November</option>
                            <option>December</option>
</select>

                            <select name="year" required>
                                <option value="">Year</option>
                                <option>2000</option>
                                <option>2001</option>
                                <option>2002</option>
                                <option>2003</option>
                                <option>2004</option>
                                <option>2005</option>
                                <option>2006</option>
                                <option>2007</option>
                                <option>2008</option>
                                <option>2009</option>
                                <option>2010</option>
                                <option>2011</option>
                                <option>2012</option>
                                <option>2013</option>
                                <option>2014</option>
                                <option>2015</option>
                                <option>2016</option>
                                <option>2017</option>
                                <option>2018</option>
                                <option>2019</option>
                                <option>2020</option>
                                <option>2021</option>
                                <option>2022</option>
                                <option>2023</option>
                                <option>2024</option>
                                <option>2025</option>
                            </select>
                        </div>
                    </td>
                </tr>
                
                <!-- EMAIL ID -->
                <tr>
                    <td class="label">EMAIL ID</td>
                    <td class="input-field"><input type="email" name="email" required></td>
                </tr>
                
                <!-- MOBILE NUMBER -->
                <tr>
                    <td class="label">MOBILE NUMBER</td>
                    <td class="input-field"><input type="text" name="mobile" required></td>
                </tr>
                
                <!-- GENDER -->
                <tr>
                    <td class="label">GENDER</td>
                    <td class="input-field">
                        <div class="checkbox-group">
                            <label><input type="radio" name="gender" value="Male" required> Male</label>
                            <label><input type="radio" name="gender" value="Female" required> Female</label>
                        </div>
                    </td>
                </tr>
                
                <!-- ADDRESS -->
                <tr>
                    <td class="label">ADDRESS</td>
                    <td class="input-field"><textarea name="address" required></textarea></td>
                </tr>
                
                <!-- CITY -->
                <tr>
                    <td class="label">CITY</td>
                    <td class="input-field"><input type="text" name="city" required></td>
                </tr>
                
                <!-- PIN CODE -->
                <tr>
                    <td class="label">PIN CODE</td>
                    <td class="input-field"><input type="text" name="pin_code" required></td>
                </tr>
                
                <!-- STATE -->
                <tr>
                    <td class="label">STATE</td>
                    <td class="input-field"><input type="text" name="state" required></td>
                </tr>
                
                <!-- COUNTRY -->
                <tr>
                    <td class="label">COUNTRY</td>
                    <td class="input-field"><input type="text" name="country" value="Rwanda" required></td>
                </tr>
                <!-- HOBBIES -->
                <tr>
                    <td class="label">HOBBIES</td>
                    <td class="input-field">
                        <input type="checkbox" name="hobbies[]" value="drawing"> Drawing
                        <input type="checkbox" name="hobbies[]" value="singing"> Singing
                        <input type="checkbox" name="hobbies[]" value="dancing"> Dancing
                        <input type="checkbox" name="hobbies[]" value="sketching"> Sketching
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="hobbies[]" value="other" id="other_checkbox"> Other
                        <input type="text" name="other_hobby" id="other_hobby" style="width:120px; margin-left: 10px;" disabled>
                    </td>
                </tr>
                <!-- QUALIFICATIONS -->
                <tr>
                    <td class="label" style="vertical-align: top;">QUALIFICATION</td>
                    <td class="input-field">
                        <table class="qual-table">
                            <thead>
                                <tr>
                                    <th>S.No</th>
                                    <th>Examination</th>
                                    <th>Board</th>
                                    <th>Percentage</th>
                                    <th>Year of Passing</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Class X</td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Class XII</td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Graduation</td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Masters</td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                    <td><input type="text"></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                
                <!-- COURSES APPLIED FOR -->
                <tr>
                    <td class="label">COURSES APPLIED FOR</td>
                    <td class="input-field">
                        <div class="checkbox-group">
                            <label><input type="radio" name="course" value="BCA" required> BCA</label>
                            <label><input type="radio" name="course" value="B.Com" required> B.Com</label>
                            <label><input type="radio" name="course" value="B.Sc" required> B.Sc</label>
                            <label><input type="radio" name="course" value="B.A" required> B.A</label>
                        </div>
                    </td>
                </tr>
            </table>

            <!-- BUTTONS -->
            <div class="button-container">
                <button type="submit">Submit</button>
                <button type="reset">Reset</button>
            </div>
        </form>
    </div>

    <script>
        // Enable/disable other hobby text field
        document.getElementById('other_checkbox').addEventListener('change', function() {
            document.getElementById('other_hobby').disabled = !this.checked;
            if (!this.checked) {
                document.getElementById('other_hobby').value = '';
            }
        });
    </script>
</body>
</html>
