-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 19, 2026 at 06:53 PM
-- Server version: 8.0.21
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `day` int DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `address` text,
  `city` varchar(50) DEFAULT NULL,
  `pin_code` varchar(10) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `hobbies` text,
  `course` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `last_name`, `day`, `month`, `year`, `email`, `mobile`, `gender`, `address`, `city`, `pin_code`, `state`, `country`, `hobbies`, `course`) VALUES
(1, 'Uwase', 'Merci', 2, 'March', 2005, 'merciuwase@gmail.com', '12345678', 'Male', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'drawing, singing', 'BCA'),
(2, 'Uwase', 'Merci', 2, 'March', 2005, 'merciuwase@gmail.com', '12345678', 'Male', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'drawing, singing', 'BCA'),
(3, 'Uwase', 'Merci', 2, 'March', 2005, 'merciuwase@gmail.com', '12345678', 'Male', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'drawing, singing', 'BCA'),
(4, 'Uwase', 'Merci', 13, 'November', 2016, 'merciuwase@gmail.com', '12345678', 'Female', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'singing, dancing', 'B.Sc'),
(5, 'Uwase', 'Merci', 14, 'December', 2014, 'merciuwase@gmail.com', '12345678', 'Female', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'dancing, sketching', 'B.A'),
(6, 'Uwase', 'Merci', 17, 'December', 2016, 'merciuwase@gmail.com', '12345678', 'Female', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'drawing, singing', 'B.Sc'),
(7, 'Uwase', 'Merci', 3, 'April', 2016, 'merciuwase@gmail.com', '12345678', 'Female', 'sdfg', 'dfg', '123456', 'west', 'Rwanda', 'drawing, singing', 'B.Sc');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
