// ========================================
// MOBILE MENU TOGGLE
// ========================================

document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.querySelector('.nav-menu');

    // Update cart count on page load
    updateCartCount();

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }

    // Close menu when a link is clicked
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navMenu.classList.remove('active');
            hamburger.classList.remove('active');
        });
    });

    // ========================================
    // CAROUSEL FUNCTIONALITY
    // ========================================
    let currentImageIndex = 0;
    const carouselImages = document.querySelectorAll('.carousel-image');
    const dots = document.querySelectorAll('.dot');

    function showImage(index) {
        // Remove active class from all images and dots
        carouselImages.forEach(img => img.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        // Add active class to current image and dot
        if (carouselImages[index]) {
            carouselImages[index].classList.add('active');
            dots[index].classList.add('active');
        }
    }

    // Auto rotate carousel every 4 seconds
    function autoRotate() {
        currentImageIndex = (currentImageIndex + 1) % carouselImages.length;
        showImage(currentImageIndex);
    }

    let carouselInterval = setInterval(autoRotate, 4000);

    // Dot click functionality
    dots.forEach((dot, index) => {
        dot.addEventListener('click', function() {
            currentImageIndex = index;
            showImage(currentImageIndex);
            clearInterval(carouselInterval);
            carouselInterval = setInterval(autoRotate, 4000);
        });
    });
});

// ========================================
// FORM VALIDATION - ORDER PAGE
// ========================================

function validateOrderForm(event) {
    const fullname = document.getElementById('fullname')?.value.trim();
    const email = document.getElementById('email')?.value.trim();
    const phone = document.getElementById('phone')?.value.trim();
    const address = document.getElementById('address')?.value.trim();
    const menuItem = document.getElementById('menu')?.value.trim();
    const deliveryDate = document.getElementById('date')?.value.trim();

    // Validation messages
    let errors = [];

    if (!fullname) {
        errors.push('Please enter your name');
    }

    if (!email) {
        errors.push('Please enter your email');
    } else if (!isValidEmail(email)) {
        errors.push('Please enter a valid email address');
    }

    if (!phone) {
        errors.push('Please enter your phone number');
    } else if (!isValidPhone(phone)) {
        errors.push('Please enter a valid phone number');
    }

    if (!address) {
        errors.push('Please enter your delivery address');
    }

    if (!menuItem) {
        errors.push('Please select a menu item');
    }

    if (!deliveryDate) {
        errors.push('Please select a delivery date');
    }

    if (errors.length > 0) {
        event.preventDefault();
        showError(errors.join('\n'));
        return false;
    }

    return true;
}

// Email validation function
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Phone validation function
function isValidPhone(phone) {
    const phoneRegex = /^\d{10,}$/;
    return phoneRegex.test(phone.replace(/\D/g, ''));
}

// Show error message
function showError(message) {
    alert('❌ Error:\n' + message);
}

// Show success message
function showSuccess(message) {
    alert('✅ ' + message);
}

// ========================================
// CONTACT FORM VALIDATION
// ========================================

function validateContactForm(event) {
    event.preventDefault();

    const fullname = document.getElementById('fullname')?.value.trim();
    const email = document.getElementById('email')?.value.trim();
    const phone = document.getElementById('phone')?.value.trim();
    const location = document.getElementById('location')?.value.trim();
    const message = document.getElementById('message')?.value.trim();

    let errors = [];

    if (!fullname) {
        errors.push('Please enter your name');
    }

    if (!email) {
        errors.push('Please enter your email');
    } else if (!isValidEmail(email)) {
        errors.push('Please enter a valid email');
    }

    if (!phone) {
        errors.push('Please enter your phone number');
    } else if (!isValidPhone(phone)) {
        errors.push('Please enter a valid phone number');
    }

    if (!location) {
        errors.push('Please enter your location');
    }

    if (!message || message.length < 10) {
        errors.push('Please enter a message (at least 10 characters)');
    }

    if (errors.length > 0) {
        showError(errors.join('\n'));
        return false;
    }

    document.querySelector('form').submit();
    return true;
}

// ========================================
// ROOM RESERVATION FORM VALIDATION
function validateRoomForm(event) {
    const fullname = document.getElementById('fullname')?.value.trim();
    const email = document.getElementById('email')?.value.trim();
    const phone = document.getElementById('phone')?.value.trim();
    const roomType = document.getElementById('room_type')?.value.trim();
    const checkinDate = document.getElementById('checkin_date')?.value.trim();
    const checkoutDate = document.getElementById('checkout_date')?.value.trim();
    const guests = document.getElementById('guests')?.value.trim();

    let errors = [];

    if (!fullname) {
        errors.push('Please enter your name');
    }

    if (!email) {
        errors.push('Please enter your email');
    } else if (!isValidEmail(email)) {
        errors.push('Please enter a valid email address');
    }

    if (!phone) {
        errors.push('Please enter your phone number');
    } else if (!isValidPhone(phone)) {
        errors.push('Please enter a valid phone number');
    }

    if (!roomType) {
        errors.push('Please select a room or conference option');
    }

    if (!checkinDate) {
        errors.push('Please select a check-in date');
    }

    if (!checkoutDate) {
        errors.push('Please select a check-out date');
    }

    if (checkinDate && checkoutDate && checkoutDate < checkinDate) {
        errors.push('Check-out date must be the same as or after check-in date');
    }

    if (!guests || Number(guests) < 1) {
        errors.push('Please enter a valid number of guests');
    }

    if (errors.length > 0) {
        event.preventDefault();
        showError(errors.join('\n'));
        return false;
    }

    return true;
}

// ========================================
// GALLERY IMAGE REDIRECT
// ========================================

function redirectToOrder(itemName) {
    // Store the selected item in sessionStorage
    sessionStorage.setItem('selectedItem', itemName);
    // Redirect to order page
    window.location.href = 'order.html?item=' + encodeURIComponent(itemName);
}

// Check if an item was selected from gallery
function checkSelectedItem() {
    const urlParams = new URLSearchParams(window.location.search);
    const selectedItem = urlParams.get('item') || sessionStorage.getItem('selectedItem');
    
    if (selectedItem) {
        const checkbox = document.querySelector(`input[name="items"][value="${selectedItem}"]`);
        if (checkbox) {
            checkbox.checked = true;
            sessionStorage.removeItem('selectedItem');
        }
    }
}

// ========================================
// SMOOTH SCROLL BEHAVIOR
// ========================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href !== '#') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// ========================================
// HIGHLIGHT ACTIVE NAV LINK
// ========================================

window.addEventListener('load', function() {
    const currentLocation = location.pathname;
    const menuItems = document.querySelectorAll('.nav-menu a');

    menuItems.forEach(item => {
        if (item.getAttribute('href').includes(currentLocation.split('/').pop()) || 
            (currentLocation.endsWith('/') && item.getAttribute('href') === 'index.html')) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // Call check selected item when on order page
    if (currentLocation.includes('order.html')) {
        checkSelectedItem();
    }
});

// ========================================
// QUANTITY SELECTOR (Optional enhancement)
// ========================================

function updateQuantity(button, change) {
    const input = button.parentElement.querySelector('input[type="number"]');
    let currentValue = parseInt(input.value) || 1;
    let newValue = currentValue + change;
    
    if (newValue >= 1) {
        input.value = newValue;
    }
}

// ========================================
// LOCAL STORAGE FUNCTIONS
// ========================================

function saveOrderToLocalStorage(orderData) {
    localStorage.setItem('lastOrder', JSON.stringify(orderData));
}

function getLastOrderFromLocalStorage() {
    const lastOrder = localStorage.getItem('lastOrder');
    return lastOrder ? JSON.parse(lastOrder) : null;
}

function clearOrderFromLocalStorage() {
    localStorage.removeItem('lastOrder');
}

// ========================================
// SHOPPING CART FUNCTIONS
// ========================================

function getCart() {
    const cart = localStorage.getItem('cart');
    return cart ? JSON.parse(cart) : {};
}

function saveCart(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function addToCart(itemName, price) {
    const cart = getCart();
    
    if (cart[itemName]) {
        cart[itemName].quantity += 1;
    } else {
        cart[itemName] = {
            price: price,
            quantity: 1
        };
    }
    
    saveCart(cart);
    updateCartCount();
    showAddToCartNotification(itemName);
}

function updateCartCount() {
    const cart = getCart();
    let totalItems = 0;
    
    for (const item in cart) {
        totalItems += cart[item].quantity;
    }
    
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = totalItems;
    }
}

function showAddToCartNotification(itemName) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: white;
        color: #2c3e50;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        z-index: 2000;
        text-align: center;
        min-width: 350px;
    `;
    
    notification.innerHTML = `
        <div style="margin-bottom: 1.5rem;">
            <div style="font-size: 2rem; margin-bottom: 1rem;">✓</div>
            <h3 style="color: #27ae60; margin: 0 0 0.5rem 0;">Success!</h3>
            <p style="margin: 0; font-size: 1.1rem;">${itemName} added to cart!</p>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
            <button onclick="window.location.href='cart.php'" style="
                padding: 0.8rem 1.5rem;
                background-color: #f39c12;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-weight: bold;
                font-size: 1rem;
            ">Go to Cart</button>
            <button onclick="this.closest('div').parentElement.remove(); updateCartCount();" style="
                padding: 0.8rem 1.5rem;
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-weight: bold;
                font-size: 1rem;
            ">Continue Shopping</button>
        </div>
    `;
    
    document.body.appendChild(notification);
}

// ========================================
// CAROUSEL FUNCTIONALITY
// ========================================

let currentSlideIndex = 0;
let carouselInterval;

function showSlide(index) {
    const images = document.querySelectorAll('.carousel-image');
    const dots = document.querySelectorAll('.dot');
    
    if (!images.length) {
        console.warn('No carousel images found');
        return;
    }
    
    // Calculate proper index
    if (index >= images.length) {
        currentSlideIndex = 0;
    } else if (index < 0) {
        currentSlideIndex = images.length - 1;
    } else {
        currentSlideIndex = index;
    }
    
    // Update images
    images.forEach((img, i) => {
        if (i === currentSlideIndex) {
            img.classList.add('active');
        } else {
            img.classList.remove('active');
        }
    });
    
    // Update dots
    dots.forEach((dot, i) => {
        if (i === currentSlideIndex) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
    
    console.log('Displaying slide:', currentSlideIndex + 1, 'of', images.length);
}

function currentSlide(index) {
    clearInterval(carouselInterval);
    showSlide(index);
    startCarouselAutoPlay();
}

function nextSlide() {
    showSlide(currentSlideIndex + 1);
}

function prevSlide() {
    showSlide(currentSlideIndex - 1);
}

function startCarouselAutoPlay() {
    carouselInterval = setInterval(() => {
        nextSlide();
    }, 5000); // Change image every 5 seconds
}

// Initialize carousel when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('🏨 Hotel Website Carousel Starting...');
    
    const carousel = document.querySelector('.hero-carousel');
    const images = document.querySelectorAll('.carousel-image');
    
    if (carousel && images.length > 0) {
        console.log('✓ Found', images.length, 'carousel images');
        console.log('✓ Image sources:', Array.from(images).map(img => img.src).join(', '));
        
        // Start carousel
        showSlide(0);
        startCarouselAutoPlay();
        console.log('✓ Carousel initialized - Auto-play active (5 second intervals)');
    } else {
        console.error('✗ Carousel setup failed - carousel or images not found');
    }
});
