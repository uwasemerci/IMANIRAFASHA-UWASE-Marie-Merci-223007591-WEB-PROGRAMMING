<?php
session_start();
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited about page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .about-hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            padding: 80px 20px;
            margin-bottom: 50px;
        }
        
        .about-hero h2 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .about-hero p {
            font-size: 20px;
            opacity: 0.95;
        }
        
        .about-content {
            display: flex;
            gap: 50px;
            align-items: center;
            margin: 60px 0;
            flex-wrap: wrap;
        }
        
        .about-text {
            flex: 1;
            min-width: 300px;
        }
        
        .about-text h3 {
            font-size: 32px;
            color: #333;
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 15px;
        }
        
        .about-text h3:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .about-text p {
            color: #666;
            line-height: 1.8;
            margin-bottom: 20px;
        }
        
        .about-image {
            flex: 1;
            min-width: 300px;
        }
        
        .about-image img {
            width: 100%;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .history-section {
            background: #f8f9fa;
            padding: 50px;
            border-radius: 15px;
            margin: 40px 0;
        }
        
        .timeline {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
        }
        
        .timeline-item {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .timeline-item:hover {
            transform: translateY(-5px);
        }
        
        .timeline-item h4 {
            color: #e67e22;
            margin-bottom: 15px;
            font-size: 1.2rem;
        }
        
        .timeline-item p {
            color: #666;
            line-height: 1.6;
        }
        
        .features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin: 60px 0;
        }
        
        .feature-card {
            text-align: center;
            padding: 40px 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
        }
        
        .feature-icon {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .feature-card h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 24px;
        }
        
        .feature-card p {
            color: #666;
            line-height: 1.6;
        }
        
        .special-offer {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            padding: 60px 20px;
            margin: 40px 0;
            border-radius: 15px;
        }
        
        .special-offer h3 {
            font-size: 32px;
            margin-bottom: 15px;
        }
        
        .special-offer p {
            font-size: 18px;
            margin-bottom: 25px;
        }
        
        .placeholder-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            width: 100%;
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 15px;
            font-size: 80px;
            color: white;
        }
        
        .cart-icon-wrapper {
            position: relative;
            margin-left: 20px;
        }
        
        .cart-icon {
            position: relative;
            display: inline-block;
            font-size: 24px;
            text-decoration: none;
            color: #333;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -12px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .about-hero h2 {
                font-size: 32px;
            }
            
            .about-hero p {
                font-size: 16px;
            }
            
            .about-content {
                flex-direction: column;
            }
            
            .timeline {
                grid-template-columns: 1fr;
            }
            
            .features {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php" class="active">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>

                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- About Hero Section -->
    <div class="about-hero">
        <h2>About Our Hotel</h2>
        <p>Your Premier Destination for Fine Dining and Hospitality</p>
    </div>

    <!-- Main Container -->
    <div class="container">
        <!-- Story Section -->
        <section class="about-content">
            <div class="about-text">
                <h3>Our Story</h3>
                <p>
                    Founded in 2013, M<sup>2</sup> Hotel has been serving discerning guests with exceptional cuisine and 
                    world-class hospitality for over a decade. What began as a small family-owned restaurant 
                    has grown into one of the region's most prestigious establishments.
                </p>
                <p>
                    Our commitment to excellence is evident in every aspect of our operation – from the carefully selected 
                    ingredients we use, to the dedicated training of our staff, to the elegant ambiance we've created for 
                    our valued guests.
                </p>
            </div>
            <div class="about-image">
                <img src="images/chef.jpg" alt="Chef preparing food">
            </div>
        </section>

        <!-- Mission & Vision -->
        <section class="history-section">
            <div class="timeline">
                <div class="timeline-item">
                    <h4>🎯 Our Mission</h4>
                    <p>
                        To deliver exceptional dining experiences by combining culinary excellence with warm, 
                        personalized service in an elegant setting that feels like home.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>👁️ Our Vision</h4>
                    <p>
                        To be recognized as the finest hotel and restaurant destination, celebrated for innovative 
                        cuisine, impeccable service, and creating lasting memories for every guest.
                    </p>
                </div>
            </div>
        </section>

        <!-- History Timeline -->
        <section class="history-section">
            <h3 style="text-align: center; color: #2c3e50; margin-bottom: 2rem;">📜 Our Journey</h3>
            <div class="timeline">
                <div class="timeline-item">
                    <h4>2013 - The Beginning</h4>
                    <p>
                        M<sup>2</sup> Hotel opens its doors as a small restaurant with just 50 seats. Our founder believed 
                        in serving only the finest ingredients and providing personal attention to each guest.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>2015 - Expansion</h4>
                    <p>
                        Due to growing popularity, we expanded to 150 seats and added 20 M<sup>2</sup> hotel rooms. 
                        We maintained our commitment to quality while accommodating more guests.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>2018 - Recognition</h4>
                    <p>
                        M<sup>2</sup> Hotel received its first award, recognizing our culinary excellence and 
                        dedication to customer satisfaction.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>2020 - Modern Era</h4>
                    <p>
                        We modernized our operations while preserving our traditions, introducing online ordering 
                        and refined our menu with contemporary cuisine.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>2026 - Today</h4>
                    <p>
                        M<sup>2</sup> Hotel stands as a beacon of hospitality with 60+ staff members, a 4.9-star rating, 
                        and thousands of satisfied guests annually.
                    </p>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section class="about-content" style="padding: 3rem 0;">
            <div class="about-image">
                <div class="placeholder-box">👨‍🍳 Our Team</div>
            </div>
            <div class="about-text">
                <h3>Our Team</h3>
                <p>
                    Our executive chef, Chef Marco Rossi, brings 30 years of culinary experience from the finest restaurants 
                    in Europe. He leads a team of talented chefs and culinary experts dedicated to creating unforgettable dishes.
                </p>
                <p>
                    Our front-of-house staff is trained to provide attentive, personalized service. Each team member shares 
                    our passion for hospitality and excellence.
                </p>
                <p>
                    Behind the scenes, our support team ensures every detail is perfect – from sourcing ingredients to 
                    maintaining our facilities to the highest standards.
                </p>
            </div>
        </section>

        <!-- Why Choose Us -->
        <section class="features">
            <div class="feature-card">
                <div class="feature-icon">🌟</div>
                <h3>Premium Quality</h3>
                <p>We source only the finest ingredients from trusted suppliers worldwide.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">👥</div>
                <h3>Expert Staff</h3>
                <p>Our team of professionals ensures exceptional service at every moment.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">✨</div>
                <h3>Elegant Setting</h3>
                <p>Beautifully designed rooms and dining areas create a memorable atmosphere.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3>Innovation</h3>
                <p>We continuously evolve our menu and services to exceed expectations.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">💚</div>
                <h3>Guest Focus</h3>
                <p>Every decision we make is centered on our guests' satisfaction and comfort.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🏆</div>
                <h3>Excellence</h3>
                <p>Award-winning cuisine and service that sets industry standards.</p>
            </div>
        </section>

        <!-- Call to Action -->
        <section class="special-offer">
            <h3>Experience M<sup>2</sup> Today</h3>
            <p>Join us for an unforgettable culinary journey</p>
            <a href="menu.php" class="btn btn-secondary">Explore Our Menu</a>
            <a href="order.php" class="btn btn-secondary" style="margin-left: 1rem;">Place an Order</a>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="order.php">Place Order</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: info@m2hotel.com</p>
                <p>Phone: 0787820195 / 3345</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
        });

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }
    </script>
</body>
</html>