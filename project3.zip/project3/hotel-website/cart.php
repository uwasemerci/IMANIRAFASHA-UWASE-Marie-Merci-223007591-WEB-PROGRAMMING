<?php
session_start();
require_once 'php/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php?error=please_login");
    exit();
}

logUserActivity('page_visit', 'Visited checkout page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .checkout-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin: 40px 0;
        }
        
        .order-summary {
            background: #f8f9fa;
            padding: 30px;
            border-radius: 15px;
            height: fit-content;
        }
        
        .order-summary h3 {
            color: #e67e22;
            margin-bottom: 20px;
        }
        
        .cart-items {
            max-height: 400px;
            overflow-y: auto;
        }
        
        .cart-item {
            display: flex;
            justify-content: space-between;
            padding: 15px 0;
            border-bottom: 1px solid #ddd;
        }
        
        .summary-totals {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 2px solid #ddd;
        }
        
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
        }
        
        .summary-row.total {
            font-size: 1.2rem;
            font-weight: bold;
            color: #e67e22;
        }
        
        .payment-form {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
        }
        
        .payment-methods {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .payment-method {
            flex: 1;
            text-align: center;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .payment-method.selected {
            border-color: #e67e22;
            background: #fff3e0;
        }
        
        .btn-pay {
            background: linear-gradient(135deg, #27ae60 0%, #2ecc71 100%);
            color: white;
            padding: 15px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
        }
        
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }
        
        .success-modal {
            background: white;
            border-radius: 20px;
            text-align: center;
            max-width: 500px;
            width: 90%;
            overflow: hidden;
        }
        
        .success-header {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            padding: 30px;
        }
        
        .success-icon {
            font-size: 60px;
        }
        
        .success-body {
            padding: 30px;
        }
        
        @media (max-width: 768px) {
            .checkout-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <div class="checkout-container">
            <div class="order-summary">
                <h3>Order Summary</h3>
                <div id="cartItems" class="cart-items"></div>
                <div class="summary-totals">
                    <div class="summary-row">
                        <span>Subtotal:</span>
                        <span id="subtotal">$0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Tax (10%):</span>
                        <span id="tax">$0.00</span>
                    </div>
                    <div class="summary-row total">
                        <span>Total:</span>
                        <span id="total">$0.00</span>
                    </div>
                </div>
            </div>

            <div class="payment-form">
                <h3>Payment Details</h3>
                <form id="paymentForm">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" id="fullname" value="<?php echo htmlspecialchars($_SESSION['customer_name'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" id="email" value="<?php echo htmlspecialchars($_SESSION['customer_email'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="tel" id="phone" value="<?php echo htmlspecialchars($_SESSION['customer_phone'] ?? ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Delivery Address</label>
                        <input type="text" id="address" placeholder="Enter your address" required>
                    </div>
                    
                    <div class="payment-methods">
                        <div class="payment-method" data-method="card">
                            <div>💳</div>
                            <small>Credit Card</small>
                        </div>
                        <div class="payment-method" data-method="mobile">
                            <div>📱</div>
                            <small>Mobile Money</small>
                        </div>
                        <div class="payment-method" data-method="cash">
                            <div>💰</div>
                            <small>Cash on Delivery</small>
                        </div>
                    </div>
                    <input type="hidden" id="paymentMethod" value="card">
                    
                    <button type="submit" class="btn-pay">Complete Payment</button>
                </form>
            </div>
        </div>
    </div>

    <div id="successModal" class="modal-overlay">
        <div class="success-modal">
            <div class="success-header">
                <div class="success-icon">✅</div>
                <h3>Payment Successful!</h3>
            </div>
            <div class="success-body">
                <p>Your order has been placed successfully!</p>
                <p><strong>Order ID:</strong> <span id="orderId"></span></p>
                <p><strong>Total Paid:</strong> <strong style="color:#e67e22" id="orderTotal"></strong></p>
                <button onclick="window.location.href='index.php'" class="btn btn-primary">Return Home</button>
                <button onclick="window.location.href='menu.php'" class="btn btn-secondary">Continue Shopping</button>
            </div>
        </div>
    </div>

    <script>
        let cartData = {};
        let totals = {};

        document.addEventListener('DOMContentLoaded', function() {
            loadCartData();
            setupPaymentMethods();
        });

        function loadCartData() {
            const savedCart = localStorage.getItem('checkoutCartData');
            const savedTotals = localStorage.getItem('checkoutTotals');
            
            if (savedCart) {
                cartData = JSON.parse(savedCart);
                totals = savedTotals ? JSON.parse(savedTotals) : { subtotal: 0, tax: 0, total: 0 };
                displayOrderSummary();
            } else {
                // Try to get from regular cart
                const regularCart = localStorage.getItem('hotelCart');
                if (regularCart) {
                    cartData = JSON.parse(regularCart);
                    calculateTotals();
                    displayOrderSummary();
                } else {
                    window.location.href = 'cart.php';
                }
            }
        }

        function calculateTotals() {
            let subtotal = 0;
            for (const item of Object.values(cartData)) {
                subtotal += item.price * item.quantity;
            }
            const tax = subtotal * 0.1;
            totals = {
                subtotal: subtotal,
                tax: tax,
                total: subtotal + tax
            };
        }

        function displayOrderSummary() {
            const cartItemsDiv = document.getElementById('cartItems');
            cartItemsDiv.innerHTML = '';
            
            for (const [id, item] of Object.entries(cartData)) {
                const itemTotal = item.price * item.quantity;
                cartItemsDiv.innerHTML += `
                    <div class="cart-item">
                        <div>
                            <strong>${item.name}</strong><br>
                            <small>Quantity: ${item.quantity}</small>
                        </div>
                        <div>$${itemTotal.toFixed(2)}</div>
                    </div>
                `;
            }
            
            document.getElementById('subtotal').textContent = '$' + totals.subtotal.toFixed(2);
            document.getElementById('tax').textContent = '$' + totals.tax.toFixed(2);
            document.getElementById('total').textContent = '$' + totals.total.toFixed(2);
        }

        function setupPaymentMethods() {
            const methods = document.querySelectorAll('.payment-method');
            methods.forEach(method => {
                method.addEventListener('click', function() {
                    methods.forEach(m => m.classList.remove('selected'));
                    this.classList.add('selected');
                    document.getElementById('paymentMethod').value = this.dataset.method;
                });
            });
        }

        document.getElementById('paymentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const address = document.getElementById('address').value;
            const paymentMethod = document.getElementById('paymentMethod').value;
            
            if (!fullname || !email || !phone || !address) {
                alert('Please fill in all fields');
                return;
            }
            
            const orderId = 'ORD-' + Date.now();
            const order = {
                orderId: orderId,
                customer: { name: fullname, email: email, phone: phone, address: address },
                items: cartData,
                totals: totals,
                paymentMethod: paymentMethod,
                orderDate: new Date().toISOString(),
                status: 'confirmed'
            };
            
            // Save order
            let orders = JSON.parse(localStorage.getItem('hotelOrders') || '[]');
            orders.push(order);
            localStorage.setItem('hotelOrders', JSON.stringify(orders));
            
            // Clear cart
            localStorage.removeItem('hotelCart');
            localStorage.removeItem('checkoutCartData');
            localStorage.removeItem('checkoutTotals');
            
            // Show success
            document.getElementById('orderId').textContent = orderId;
            document.getElementById('orderTotal').textContent = '$' + totals.total.toFixed(2);
            document.getElementById('successModal').style.display = 'flex';
        });
        
        window.onclick = function(event) {
            const modal = document.getElementById('successModal');
            if (event.target === modal) {
                modal.style.display = 'none';
                window.location.href = 'index.php';
            }
        }
    </script>
</body>
</html>