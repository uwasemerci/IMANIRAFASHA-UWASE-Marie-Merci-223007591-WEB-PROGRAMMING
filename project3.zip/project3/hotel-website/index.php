<?php
session_start();
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited home page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>M<sup>2</sup> Hotel - Home</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .welcome-banner {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            padding: 15px;
            text-align: center;
            margin: 20px auto;
            border-radius: 10px;
            max-width: 1200px;
            animation: slideDown 0.5s ease;
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .cart-icon-wrapper {
            position: relative;
            margin-left: 20px;
        }
        
        .cart-icon {
            position: relative;
            display: inline-block;
            font-size: 24px;
            text-decoration: none;
            color: #333;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -12px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .carousel-container {
            position: relative;
            width: 100%;
            height: 600px;
            overflow: hidden;
        }
        
        .carousel-image {
            position: absolute;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            transition: opacity 1s ease;
        }
        
        .carousel-image.active {
            opacity: 1;
        }
        
        .carousel-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1;
        }
        
        .hero-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            color: white;
            z-index: 2;
            width: 100%;
            padding: 20px;
        }
        
        .hero-content h2 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .hero-content p {
            font-size: 24px;
            margin-bottom: 30px;
        }
        
        .carousel-dots {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
            z-index: 2;
        }
        
        .dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: white;
            border: none;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .dot.active {
            background: #e67e22;
            transform: scale(1.2);
        }
        
        .quick-links {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin: 60px 0;
        }
        
        .quick-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s;
            text-align: center;
            padding: 20px;
        }
        
        .quick-card:hover {
            transform: translateY(-10px);
        }
        
        .quick-card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }
        
        .quick-card h3 {
            margin: 15px 0;
            color: #333;
        }
        
        .quick-card p {
            color: #666;
            margin-bottom: 20px;
        }
        
        .features {
            display: flex;
            justify-content: space-between;
            gap: 30px;
            margin: 60px 0;
            flex-wrap: wrap;
        }
        
        .feature-card {
            flex: 1;
            min-width: 250px;
            text-align: center;
            padding: 40px 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
        }
        
        .feature-icon {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .feature-card h3 {
            color: #333;
            margin-bottom: 15px;
            font-size: 24px;
        }
        
        .feature-card p {
            color: #666;
            line-height: 1.6;
        }
        
        .special-offer {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            padding: 60px 20px;
            margin: 40px 0;
            border-radius: 15px;
        }
        
        .offer-content h3 {
            font-size: 32px;
            margin-bottom: 15px;
        }
        
        .offer-content p {
            font-size: 18px;
            margin-bottom: 25px;
        }
        
        .about-preview {
            display: flex;
            gap: 30px;
            align-items: center;
            margin: auto;
            flex-wrap: wrap;
        }
        
        .about-text {
            flex: 1;
            min-width: 300px;
        }
        
        .about-text h3 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }
        
        .about-text p {
            color: #666;
            line-height: 1.8;
            margin-bottom: 20px;
        }
        
        .link-btn {
            color: #667eea;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        
        .link-btn:hover {
            color: #764ba2;
        }
        
        .about-image {
            flex: 1;
            min-width: 300px;
        }
        
        .about-image img {
            width: 100%;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        @media (max-width: 768px) {
            .features {
                flex-direction: column;
            }
            
            .about-preview {
                flex-direction: column;
            }
            
            .hero-content h2 {
                font-size: 32px;
            }
            
            .hero-content p {
                font-size: 18px;
            }
        }
    </style>
</head>
<body>
    <!-- Welcome Banner for Logged-in Users -->
    <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
    <div class="welcome-banner">
        🎉 Welcome back, <?php echo htmlspecialchars($_SESSION['customer_name'] ?? 'Guest'); ?>! 🎉
    </div>
    <?php endif; ?>
    
    <!-- Login Success Message -->
    <?php if (isset($_GET['login']) && $_GET['login'] == 'success'): ?>
    <div class="welcome-banner" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);">
        ✅ Login successful! Welcome to M<sup>2</sup> Hotel!
    </div>
    <?php endif; ?>
    
    <!-- Logout Success Message -->
    <?php if (isset($_GET['logout']) && $_GET['logout'] == 'success'): ?>
    <div class="welcome-banner" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        👋 You have been successfully logged out. Come back soon!
    </div>
    <?php endif; ?>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact </a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero">
        <div class="carousel-container">
            <img src="images/hotel1.jpg" alt="Hotel" class="carousel-image active">
            <img src="images/hotel.jpg" alt="Hotel" class="carousel-image">
            <img src="images/hotelinside.jpg" alt="Hotel Inside" class="carousel-image">
        </div>
        <div class="carousel-overlay"></div>
        <div class="hero-content">
            <h2>Welcome to M<sup>2</sup> Hotel</h2>
            <p>Experience Fine Dining at Its Finest</p>
            <a href="menu.php" class="btn btn-primary">Explore Menu</a>
        </div>
        <div class="carousel-dots">
            <button class="dot active" data-index="0"></button>
            <button class="dot" data-index="1"></button>
            <button class="dot" data-index="2"></button>
        </div>
    </div>

    <!-- Quick Link Cards -->
    <div class="container">
        <section class="quick-links">
            <div class="quick-card">
                <img src="images/hotelinside1.jpg" alt="Rooms and conference">
                <h3>Rooms & Conference</h3>
                <p>View luxurious rooms, VIP suites, and conference spaces, and reserve your stay or event.</p>
                <a href="rooms.php" class="btn btn-secondary">View Rooms</a>
            </div>
            <div class="quick-card">
                <img src="images/drinkssss/food2.jpg" alt="FOOD AND DRINKS">
                <h3>Food and Drinks</h3>
                <p>Order with us the delicious menu items and special offers.</p>
                <a href="menu.php" class="btn btn-secondary">View Menu</a>
            </div>
        </section>
    </div>

    <!-- Features Section -->
    <div class="container">
        <section class="features">
            <div class="feature-card">
                <div class="feature-icon">🍽️</div>
                <h3>Fine Dining</h3>
                <p>Exquisite cuisine prepared by our world-class chefs.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🏨</div>
                <h3>Comfort</h3>
                <p>Luxurious rooms and professional service.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">⭐</div>
                <h3>Premium Quality</h3>
                <p>The finest ingredients and highest standards.</p>
            </div>
        </section>
    </div>

    <!-- Special Offer Section -->
    <div class="special-offer">
        <div class="offer-content">
            <h3>Special Offer This Week</h3>
            <p>Get 20% discount on all beverages</p>
            <a href="order.php" class="btn btn-secondary">Order Now</a>
        </div>
    </div>

    <!-- About Preview Section -->
    <div class="container">
        <section class="about-preview">
            <div class="about-text">
                <h3>About Our Hotel</h3>
                <p>Since 2013, M<sup>2</sup> Hotel has been providing exceptional dining experiences and hospitality to guests from around the world. Our commitment to quality and excellence ensures every visit is memorable.</p>
                <a href="about.php" class="link-btn">Learn More →</a>
            </div>
            <div class="about-image">
                <img src="images/chef.jpg" alt="Chef at M2 Hotel">
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="order.php">Place Order</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: m2@info.rw</p>
                <p>Phone: +250 787820195</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
            
            // Auto-hide banners after 5 seconds
            setTimeout(function() {
                const banners = document.querySelectorAll('.welcome-banner');
                banners.forEach(banner => {
                    banner.style.display = 'none';
                });
            }, 5000);
        });

        // Carousel functionality
        let currentSlide = 0;
        const slides = document.querySelectorAll('.carousel-image');
        const dots = document.querySelectorAll('.dot');

        function changeSlide(index) {
            slides.forEach(slide => slide.classList.remove('active'));
            dots.forEach(dot => dot.classList.remove('active'));
            
            slides[index].classList.add('active');
            dots[index].classList.add('active');
            currentSlide = index;
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            changeSlide(currentSlide);
        }

        // Auto-advance slides every 5 seconds
        let slideInterval = setInterval(nextSlide, 5000);

        // Add click handlers to dots
        dots.forEach((dot, index) => {
            dot.addEventListener('click', () => {
                clearInterval(slideInterval);
                changeSlide(index);
                slideInterval = setInterval(nextSlide, 5000);
            });
        });

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }
    </script>
</body>
</html>