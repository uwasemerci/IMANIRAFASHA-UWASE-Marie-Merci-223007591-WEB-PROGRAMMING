<?php
// ============================================
// LOGOUT SCRIPT
// ============================================

session_start();
// Log logout action
require_once 'db_connection.php';
if (isset($_SESSION['customer_email'])) {
    logUserActivity('logout', 'User logged out', $_SESSION['customer_email'], '/php/logout.php');
}
// Destroy all session data
session_destroy();

// Redirect to home page
header("Location: ../index.php");
exit;
?>
