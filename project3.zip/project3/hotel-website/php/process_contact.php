<?php
// ============================================
// PROCESS CONTACT FORM
// ============================================

session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form data
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $location = sanitizeInput($_POST['location']);
    $message = sanitizeInput($_POST['message']);
    
    // Validate required fields
    if (empty($fullname) || empty($email) || empty($phone) || empty($location) || empty($message)) {
        echo "<script>alert('All fields are required!'); window.history.back();</script>";
        exit;
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!'); window.history.back();</script>";
        exit;
    }
    
    // Insert message into database
    $sql = "INSERT INTO contacts (fullname, email, phone, location, message, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("sssss", $fullname, $email, $phone, $location, $message);
    
    if ($stmt->execute()) {        // Log successful contact submission
        logUserActivity('form_submit', "Contact form submitted from: $location", $email, '/php/process_contact.php');
                echo "<script>alert('Thank you for your message! We will get back to you soon.'); window.location.href='../contact.php';</script>";
        exit;
    } else {
        echo "<script>alert('Error sending message: " . $conn->error . "'); window.history.back();</script>";
        exit;
    }
    
    $stmt->close();
}

$conn->close();
?>
