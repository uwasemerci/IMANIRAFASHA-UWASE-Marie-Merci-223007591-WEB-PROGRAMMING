<?php
// ============================================
// PROCESS CHECKOUT
// ============================================

session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form data
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $address = sanitizeInput($_POST['address']);
    $payment_method = sanitizeInput($_POST['payment_method']);
    $special_requests = sanitizeInput($_POST['special_requests'] ?? '');
    
    // Calculate total from cart
    $total_amount = floatval($_POST['total_amount'] ?? 0);
    
    // Validate required fields
    if (empty($fullname) || empty($email) || empty($phone) || empty($address) || empty($payment_method)) {
        echo "<script>alert('All required fields are required!'); window.history.back();</script>";
        exit;
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!'); window.history.back();</script>";
        exit;
    }
    
    // Process payment method validation
    if ($payment_method === 'Credit Card' || $payment_method === 'Debit Card') {
        $card_number = sanitizeInput($_POST['card_number'] ?? '');
        $expiry = sanitizeInput($_POST['expiry'] ?? '');
        $cvv = sanitizeInput($_POST['cvv'] ?? '');
        
        if (empty($card_number) || empty($expiry) || empty($cvv)) {
            echo "<script>alert('Card details are required!'); window.history.back();</script>";
            exit;
        }
        
        // Hash card information for security (do NOT store raw card data)
        $card_hash = hash('sha256', $card_number . $expiry . $cvv);
    } else {
        $card_hash = null;
    }
    
    // Create orders from cart items
    // First, get the cart from JavaScript
    $cart_items = isset($_POST['cart_items']) ? json_decode($_POST['cart_items'], true) : [];
    
    if (empty($cart_items)) {
        echo "<script>alert('Your cart is empty!'); window.location.href='../cart.php';</script>";
        exit;
    }
    
    // Create a transaction/order record
    $order_date = date('Y-m-d');
    $order_reference = 'ORD-' . time() . '-' . substr(md5(rand()), 0, 8);
    
    // Insert main order
    $order_sql = "INSERT INTO orders (fullname, email, phone, address, payment_method, total_amount, order_reference, special_requests, order_date) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $order_stmt = $conn->prepare($order_sql);
    if ($order_stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    
    $order_stmt->bind_param("sssssdsss", $fullname, $email, $phone, $address, $payment_method, $total_amount, $order_reference, $special_requests, $order_date);
    
    if ($order_stmt->execute()) {
        $order_id = $conn->insert_id;
        
        // Insert individual order items
        $item_sql = "INSERT INTO order_items (order_id, item_name, price, quantity) VALUES (?, ?, ?, ?)";
        $item_stmt = $conn->prepare($item_sql);
        
        foreach ($cart_items as $item) {
            $item_name = sanitizeInput($item['name']);
            $item_price = floatval($item['price']);
            $item_quantity = intval($item['quantity']);
            
            $item_stmt->bind_param("isdi", $order_id, $item_name, $item_price, $item_quantity);
            $item_stmt->execute();
        }
        
        $item_stmt->close();
        
        // Log successful checkout
        logUserActivity('checkout', "Completed order: $order_reference", $email, '/php/process_checkout.php');
        
        // Store order details in session
        $_SESSION['order_success'] = true;
        $_SESSION['order_id'] = $order_id;
        $_SESSION['order_reference'] = $order_reference;
        $_SESSION['customer_email'] = $email;
        $_SESSION['order_total'] = $total_amount;
        
        // Redirect to success page
        header("Location: ../checkout-success.php?order_id=" . urlencode($order_reference));
        exit;
    } else {
        echo "<script>alert('Error processing order: " . $conn->error . "'); window.history.back();</script>";
        exit;
    }
    
    $order_stmt->close();
}

$conn->close();
?>
