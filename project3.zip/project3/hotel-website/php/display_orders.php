<?php
// ============================================
// DISPLAY CUSTOMER ORDERS
// ============================================

session_start();
require_once 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo "<script>alert('Please login first!'); window.location.href='../login.php';</script>";
    exit;
}

$email = $_SESSION['customer_email'];

// Get customer orders
$sql = "SELECT * FROM orders WHERE email = ? ORDER BY order_date DESC";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="../index.php">Home</a></li>
                <li><a href="../about.php">About Us</a></li>
                <li><a href="../menu.php">Menu</a></li>
                <li><a href="../order.php">Order</a></li>
                <li><a href="../gallery.php">Gallery</a></li>
                <li><a href="../rooms.php">Rooms</a></li>
                <li><a href="../contact.php">Contact Us</a></li>
                <li><a href="logout.php" class="logout-link">Logout</a></li>
            </ul>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Orders Section -->
    <div class="container">
        <section class="orders-section">
            <h2>Your Order History</h2>
            <p class="subtitle">Email: <?php echo htmlspecialchars($email); ?></p>
            
            <?php
            if ($result->num_rows > 0) {
                echo "<table class='orders-table'>";
                echo "<thead>";
                echo "<tr>";
                echo "<th>Order ID</th>";
                echo "<th>Full Name</th>";
                echo "<th>Menu Item</th>";
                echo "<th>Address</th>";
                echo "<th>Order Date</th>";
                echo "<th>Phone</th>";
                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";
                
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['fullname']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['menu_item']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['order_date']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
                    echo "</tr>";
                }
                
                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<p class='no-orders'>No orders found.</p>";
            }
            ?>
            
            <div class="button-group">
                <a href="../order.php" class="btn btn-primary">Place New Order</a>
                <a href="logout.php" class="btn btn-secondary">Logout</a>
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="../js/script.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
