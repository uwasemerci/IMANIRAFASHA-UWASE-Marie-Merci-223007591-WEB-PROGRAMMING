<?php
// ============================================
// PROCESS ORDER FORM
// ============================================

session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get and sanitize form data
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $menu = sanitizeInput($_POST['menu']);
    $address = sanitizeInput($_POST['address']);
    $date = sanitizeInput($_POST['date']);
    
    // Validate required fields
    if (empty($fullname) || empty($email) || empty($phone) || empty($menu) || empty($address) || empty($date)) {
        echo "<script>alert('All fields are required!'); window.history.back();</script>";
        exit;
    }
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email format!'); window.history.back();</script>";
        exit;
    }
    
    // Insert order into database
    $sql = "INSERT INTO orders (fullname, email, phone, menu_item, address, order_date) 
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("ssssss", $fullname, $email, $phone, $menu, $address, $date);
    
    if ($stmt->execute()) {
        $_SESSION['order_success'] = true;
        $_SESSION['customer_email'] = $email;        
        // Log successful order
        logUserActivity('form_submit', "Placed order for: $menu", $email, '/php/process_order.php');
                header("Location: ../index.php?success=1");
        exit;
    } else {
        echo "<script>alert('Error placing order: " . $conn->error . "'); window.history.back();</script>";
        exit;
    }
    
    $stmt->close();
}

$conn->close();
?>
