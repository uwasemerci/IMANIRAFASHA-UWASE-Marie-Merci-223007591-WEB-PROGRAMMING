<?php
// ============================================
// REGISTER SCRIPT
// ============================================

session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = sanitizeInput($_POST['fullname']);
    $email = sanitizeInput($_POST['email']);
    $phone = sanitizeInput($_POST['phone']);
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($fullname) || empty($email) || empty($phone) || empty($password) || empty($confirm_password)) {
        echo "<script>alert('All fields are required.'); window.history.back();</script>";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Enter a valid email address.'); window.history.back();</script>";
        exit;
    }

    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match.'); window.history.back();</script>";
        exit;
    }

    // Check if user already exists
    $checkSql = "SELECT 1 FROM users WHERE email = ?";
    $checkStmt = $conn->prepare($checkSql);
    if ($checkStmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo "<script>alert('An account with this email already exists. Please login.'); window.location.href='../login.php';</script>";
        exit;
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $insertSql = "INSERT INTO users (full_name, email, phone, password, created_at) VALUES (?, ?, ?, ?, NOW())";
    $insertStmt = $conn->prepare($insertSql);
    if ($insertStmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $insertStmt->bind_param("ssss", $fullname, $email, $phone, $passwordHash);
    if ($insertStmt->execute()) {
        logUserActivity('register', 'New user registered', $email, '/php/register.php');
        echo "<script>alert('Registration successful! Please login to view your orders.'); window.location.href='../login.php';</script>";
        exit;
    } else {
        echo "<script>alert('Registration failed. Please try again.'); window.history.back();</script>";
        exit;
    }

    $checkStmt->close();
    $insertStmt->close();
}

$conn->close();
?>