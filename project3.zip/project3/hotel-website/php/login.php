<?php
// ============================================
// LOGIN SCRIPT - FIXED VERSION
// ============================================

session_start();
require_once 'db_connection.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Check if email and password are set
    if (!isset($_POST['email']) || !isset($_POST['password'])) {
        header("Location: ../login.php?error=failed");
        exit();
    }
    
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];

    // Validate inputs
    if (empty($email) || empty($password)) {
        header("Location: ../login.php?error=failed");
        exit();
    }

    // Prepare SQL statement
    $sql = "SELECT full_name, email, phone, password FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['logged_in'] = true;
            $_SESSION['customer_email'] = $user['email'];
            $_SESSION['customer_phone'] = $user['phone'];
            $_SESSION['customer_name'] = $user['full_name'];

            // Log successful login
            if (function_exists('logUserActivity')) {
                logUserActivity('login', 'Successful login', $email, '/php/login.php');
            }

            $stmt->close();
            $conn->close();

            // Redirect to index.php
            header("Location: ../index.php?login=success");
            exit();
        }
    }

    // Login failed
    $stmt->close();
    if (function_exists('logUserActivity')) {
        logUserActivity('login', 'Failed login attempt', $email, '/php/login.php');
    }
    header("Location: ../login.php?error=failed");
    exit();
}

// If not POST request, redirect to login page
header("Location: ../login.php");
exit();

$conn->close();
?>