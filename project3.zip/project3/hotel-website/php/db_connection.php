<?php
// ============================================
// DATABASE CONNECTION FILE
// ============================================

// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8
$conn->set_charset("utf8");

// Function to sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to log user activities
function logUserActivity($action_type, $action_details = '', $user_email = null, $page_url = null) {
    global $conn;

    $user_ip = $_SERVER['REMOTE_ADDR'];
    $page_url = $page_url ?: $_SERVER['REQUEST_URI'];

    $sql = "INSERT INTO user_activities (user_email, user_ip, action_type, action_details, page_url) VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        return false; // Log failure silently
    }

    $stmt->bind_param("sssss", $user_email, $user_ip, $action_type, $action_details, $page_url);

    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

// Function to get user initials for display
function getUserInitials($name) {
    $name = trim($name);
    if ($name === '') {
        return 'U';
    }

    $parts = preg_split('/\s+/', $name);
    if (count($parts) === 1) {
        return strtoupper(substr($parts[0], 0, 1));
    }

    $initials = strtoupper(substr($parts[0], 0, 1) . substr(end($parts), 0, 1));
    return $initials;
}

?>

