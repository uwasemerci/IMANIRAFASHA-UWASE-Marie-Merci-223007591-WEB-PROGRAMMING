<?php
// ============================================
// ROOM BOOKING PROCESS SCRIPT
// ============================================

session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = sanitizeInput($_POST['fullname'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $phone = sanitizeInput($_POST['phone'] ?? '');
    $room_type = sanitizeInput($_POST['room_type'] ?? '');
    $checkin_date = sanitizeInput($_POST['checkin_date'] ?? '');
    $checkout_date = sanitizeInput($_POST['checkout_date'] ?? '');
    $guests = intval($_POST['guests'] ?? 1);
    $special_requests = sanitizeInput($_POST['special_requests'] ?? '');

    if (empty($fullname) || empty($email) || empty($phone) || empty($room_type) || empty($checkin_date) || empty($checkout_date) || $guests < 1) {
        echo "<script>alert('Please complete all required reservation fields.'); window.history.back();</script>";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Enter a valid email address.'); window.history.back();</script>";
        exit;
    }

    if (strtotime($checkout_date) < strtotime($checkin_date)) {
        echo "<script>alert('Check-out date must be the same as or after check-in.'); window.history.back();</script>";
        exit;
    }

    $insertSql = "INSERT INTO room_reservations (fullname, email, phone, room_type, checkin_date, checkout_date, guests, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);

    if ($insertStmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $insertStmt->bind_param("ssssssss", $fullname, $email, $phone, $room_type, $checkin_date, $checkout_date, $guests, $special_requests);

    if ($insertStmt->execute()) {
        logUserActivity('room_booking', 'Submitted room/conference reservation', $email, '/php/process_room_booking.php');
        echo "<script>alert('Reservation request submitted successfully! We will contact you shortly.'); window.location.href='../rooms.php';</script>";
        exit;
    } else {
        echo "<script>alert('Unable to submit reservation at this time. Please try again later.'); window.history.back();</script>";
        exit;
    }

    $insertStmt->close();
}

$conn->close();
?>