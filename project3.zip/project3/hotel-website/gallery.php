<?php
session_start();
// Log page visit
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited gallery page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/gallery.css">
</head>
<body>
    <!-- Login Required Modal -->
    <div id="loginModal" class="modal-overlay">
        <div class="login-modal">
            <div class="modal-header login">
                <span class="close-modal" onclick="closeLoginModal()">&times;</span>
                <div class="modal-icon">🔐</div>
                <h3>Login Required</h3>
                <p>Please sign in to add items to your cart</p>
            </div>
            <div class="modal-body">
                <p style="color: #666; margin-bottom: 20px;">Create an account or login to continue shopping with us!</p>
                <div class="btn-group">
                    <button onclick="window.location.href='login.php'" class="btn-modal btn-login">Login Now</button>
                    <button onclick="window.location.href='register.php'" class="btn-modal btn-register">Create Account</button>
                    <button onclick="closeLoginModal()" class="btn-modal btn-cancel">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal-overlay">
        <div class="success-modal">
            <div class="modal-header success">
                <span class="close-modal" onclick="closeSuccessModal()">&times;</span>
                <div class="modal-icon">✅</div>
                <h3>Added to Cart!</h3>
                <p>Your item has been successfully added</p>
            </div>
            <div class="modal-body">
                <div class="item-details">
                    <div class="item-name" id="successItemName">Item Name</div>
                    <div class="item-price" id="successItemPrice">$0.00</div>
                </div>
                <div class="btn-group">
                    <button onclick="goToCart()" class="btn-modal btn-cart">View Cart 🛒</button>
                    <button onclick="closeSuccessModal()" class="btn-modal btn-continue">Continue Shopping</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php" class="active">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>

                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Gallery Title Section -->
    <div class="container">
        <div class="gallery-title">
            <h2>Photo Gallery</h2>
            <p>Click on any image to order that item</p>
            <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
                <div class="warning-banner">
                    🎯 Please login or create an account to start ordering! 🎯
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Gallery Banner -->
    <div class="container">
        <div class="gallery-banner">
            <div class="gallery-banner-text">
                <h3>Meet Our Chef</h3>
                <p>Our chef brings the finest flavors to every dish, ensuring premium taste and beautiful presentation.</p>
            </div>
            <div class="gallery-banner-image">
                <img src="images/chef.jpg" alt="Chef at M2 Hotel">
            </div>
        </div>
    </div>

    <!-- Gallery Grid -->
    <div class="container">
        <div class="gallery-grid">
            <!-- Gallery Item 1 - Grilled Salmon -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Grilled Salmon Fillet', 28.99, 'images/fish.jpg')">
                <img src="images/drinkssss/fish.jpg" alt="Grilled Salmon Fillet">
                <div class="gallery-item-label">Grilled Salmon Fillet - $28.99</div>
            </div>

            <!-- Gallery Item 2 - Wagyu Beef Steak -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Wagyu Beef Steak', 85.00, 'images/drinkssss/food1.jpg')">
                <img src="images/drinkssss/food1.jpg" alt="Wagyu Beef Steak">
                <div class="gallery-item-label">Wagyu Beef Steak - $85.00</div>
            </div>

            <!-- Gallery Item 3 - Mushroom Risotto -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Wild Mushroom Risotto', 22.50, 'images/drinkssss/food2.jpg')">
                <img src="images/drinkssss/food2.jpg" alt="Wild Mushroom Risotto">
                <div class="gallery-item-label">Wild Mushroom Risotto - $22.50</div>
            </div>

            <!-- Gallery Item 4 - Fresh Orange Juice -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Fresh Orange Juice', 6.99, 'images/drinkssss/drink1.jpg')">
                <img src="images/drinkssss/drink1.jpg" alt="Fresh Orange Juice">
                <div class="gallery-item-label">Fresh Orange Juice - $6.99</div>
            </div>

            <!-- Gallery Item 5 - Chocolate Lava Cake -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Chocolate Lava Cake', 12.99, 'images/drinkssss/food3.jpg')">
                <img src="images/drinkssss/food3.jpg" alt="Chocolate Lava Cake">
                <div class="gallery-item-label">Chocolate Lava Cake - $12.99</div>
            </div>

            <!-- Gallery Item 6 - Champagne -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Champagne - Moët & Chandon', 89.00, 'images/drinkssss/drink2.jpg')">
                <img src="images/drinkssss/drink2.jpg" alt="Champagne">
                <div class="gallery-item-label">Champagne - Moët & Chandon - $89.00</div>
            </div>

            <!-- Gallery Item 7 - Lamb Chops -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Herb-Crusted Lamb Chops', 42.00, 'images/drinkssss/food4.jpg')">
                <img src="images/drinkssss/food4.jpg" alt="Herb-Crusted Lamb Chops">
                <div class="gallery-item-label">Herb-Crusted Lamb Chops - $42.00</div>
            </div>

            <!-- Gallery Item 8 - Berry Smoothie -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Strawberry Banana Smoothie', 7.99, 'images/drinkssss/drink3.jpg')">
                <img src="images/drinkssss/drink3.jpg" alt="Strawberry Banana Smoothie">
                <div class="gallery-item-label">Strawberry Banana Smoothie - $7.99</div>
            </div>

            <!-- Gallery Item 9 - Tiramisu -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Tiramisu', 11.99, 'images/drinkssss/food5.jpg')">
                <img src="images/drinkssss/food5.jpg" alt="Tiramisu">
                <div class="gallery-item-label">Tiramisu - $11.99</div>
            </div>

            <!-- Gallery Item 10 - Grilled Sea Bass -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Grilled Sea Bass', 32.00, 'images/drinkssss/fish.jpg')">
                <img src="images/drinkssss/fish.jpg" alt="Grilled Sea Bass">
                <div class="gallery-item-label">Grilled Sea Bass - $32.00</div>
            </div>

            <!-- Gallery Item 11 - Caesar Salad -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Caesar Salad', 14.99, 'images/salad.jpg')">
                <img src="images/salad.jpg" alt="Caesar Salad">
                <div class="gallery-item-label">Caesar Salad - $14.99</div>
            </div>

            <!-- Gallery Item 12 - Margherita Pizza -->
            <div class="gallery-item" onclick="checkLoginAndAddToCart('Margherita Pizza', 18.99, 'images/pizza.jpg')">
                <img src="images/pizza.jpg" alt="Margherita Pizza">
                <div class="gallery-item-label">Margherita Pizza - $18.99</div>
            </div>
        </div>
    </div>

    <!-- Fish Menu Preview Section -->
    <div class="container">
        <section class="menu-preview">
            <div class="menu-preview-content">
                <h3>Explore the Full Menu</h3>
                <p>Browse our complete selection of seafood, meat dishes, desserts, and beverages.</p>
                <a href="menu.php" class="btn btn-primary">View Full Menu</a>
            </div>
            <div class="menu-preview-image">
                <img src="images/fish.jpg" alt="Fish menu">
            </div>
        </section>
    </div>

    <!-- Rooms & Conference Section -->
    <div class="container">
        <section class="room-grid">
            <div class="room-card">
                <img src="images/hotel.jpg" alt="Standard Room">
                <div class="room-card-content">
                    <h4>Standard Rooms</h4>
                    <p>Comfortable rooms with cozy bedding, high-speed Wi-Fi, and room service.</p>
                    <a href="rooms.php#reserve" class="btn btn-secondary">Reserve Now</a>
                </div>
            </div>
            <div class="room-card">
                <img src="images/hotelinside.jpg" alt="Deluxe Room">
                <div class="room-card-content">
                    <h4>Deluxe Rooms</h4>
                    <p>Elegant rooms with premium finishes, city views, and luxurious amenities.</p>
                    <a href="rooms.php#reserve" class="btn btn-secondary">Reserve Now</a>
                </div>
            </div>
            <div class="room-card">
                <img src="images/conf1.jpg" alt="Conference Room">
                <div class="room-card-content">
                    <h4>Conference Rooms</h4>
                    <p>Modern conference spaces equipped for meetings, workshops, and events.</p>
                    <a href="rooms.php#reserve" class="btn btn-secondary">Book Conference</a>
                </div>
            </div>
            <div class="room-card">
                <img src="images/conf2.jpg" alt="Event Space">
                <div class="room-card-content">
                    <h4>Event Spaces</h4>
                    <p>Spacious venues for weddings, celebrations, and corporate gatherings.</p>
                    <a href="rooms.php#reserve" class="btn btn-secondary">Book Event</a>
                </div>
            </div>
        </section>
    </div>

    <!-- Info Section -->
    <div class="container">
        <section class="special-offer">
            <h3>Ready to Order?</h3>
            <p>Click on any image above to add it to your cart, or browse our full menu</p>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                <a href="order.php" class="btn btn-secondary">Go to Order Page</a>
                <a href="menu.php" class="btn btn-secondary" style="margin-left: 1rem;">View Full Menu</a>
                <a href="cart.php" class="btn btn-primary" style="margin-left: 1rem;">View Cart</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary">Login to Order</a>
                <a href="register.php" class="btn btn-secondary" style="margin-left: 1rem;">Create Account</a>
            <?php endif; ?>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="order.php">Place Order</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: info@m2hotel.com</p>
                <p>Phone: 0787820195 / 3345</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Variables to store current item
        let currentItemName = '';
        let currentItemPrice = 0;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
        });

        function checkLoginAndAddToCart(itemName, price, image) {
            if (!isLoggedIn) {
                showLoginModal();
                return false;
            }
            
            // Store current item details
            currentItemName = itemName;
            currentItemPrice = price;
            
            // Add to cart
            addToCartAndShowSuccess(itemName, price);
        }

        function showLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        function showSuccessModal(itemName, price) {
            document.getElementById('successItemName').innerHTML = itemName;
            document.getElementById('successItemPrice').innerHTML = '$' + price.toFixed(2);
            document.getElementById('successModal').style.display = 'flex';
            
            // Auto close after 3 seconds
            setTimeout(function() {
                closeSuccessModal();
            }, 3000);
        }

        function closeSuccessModal() {
            document.getElementById('successModal').style.display = 'none';
        }

        function addToCartAndShowSuccess(itemName, price) {
            // Create cart item
            const cartItem = {
                name: itemName,
                price: parseFloat(price),
                quantity: 1,
                type: 'food',
                dateAdded: new Date().toISOString()
            };
            
            // Add to cart
            addToCart(cartItem);
            
            // Show success modal
            showSuccessModal(itemName, price);
        }

        function goToCart() {
            window.location.href = 'cart.php';
        }

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function saveCart(cart) {
            localStorage.setItem('hotelCart', JSON.stringify(cart));
            updateCartCount();
        }

        function addToCart(item) {
            const cart = getCart();
            const itemId = item.name + '_' + Date.now();
            cart[itemId] = item;
            saveCart(cart);
            updateCartCount();
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            const successModal = document.getElementById('successModal');
            if (event.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (event.target === successModal) {
                successModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>