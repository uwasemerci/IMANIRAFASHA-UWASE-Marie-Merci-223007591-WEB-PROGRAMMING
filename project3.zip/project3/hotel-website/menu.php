<?php
session_start();
// Log page visit
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited menu page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Modern Popup Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .login-modal, .success-modal {
            background: white;
            border-radius: 20px;
            text-align: center;
            max-width: 450px;
            width: 90%;
            padding: 0;
            overflow: hidden;
            animation: slideUp 0.4s ease;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .modal-header {
            padding: 30px 30px 20px;
            text-align: center;
        }
        
        .modal-header.login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .modal-header.success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .modal-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .modal-header h3 {
            font-size: 28px;
            margin: 0 0 10px;
        }
        
        .modal-header p {
            font-size: 16px;
            margin: 0;
            opacity: 0.95;
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .item-details {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        
        .item-name {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        
        .item-price {
            font-size: 24px;
            font-weight: bold;
            color: #e67e22;
            margin-top: 5px;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }
        
        .btn-modal {
            padding: 12px 25px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-modal:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-register {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .btn-cancel {
            background: #e0e0e0;
            color: #666;
        }
        
        .btn-cart {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .btn-continue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 28px;
            cursor: pointer;
            color: white;
            opacity: 0.8;
            transition: opacity 0.2s;
        }
        
        .close-modal:hover {
            opacity: 1;
        }
        
        .warning-banner {
            background: linear-gradient(135deg, #ffe259 0%, #ffa751 100%);
            color: #fff;
            padding: 12px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: bold;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }
        
        .price {
            font-weight: bold;
            color: #e67e22;
        }
        
        .menu-table button {
            padding: 8px 20px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .menu-table button:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Login Required Modal -->
    <div id="loginModal" class="modal-overlay">
        <div class="login-modal">
            <div class="modal-header login">
                <span class="close-modal" onclick="closeLoginModal()">&times;</span>
                <div class="modal-icon">🔐</div>
                <h3>Login Required</h3>
                <p>Please sign in to add items to your cart</p>
            </div>
            <div class="modal-body">
                <p style="color: #666; margin-bottom: 20px;">Create an account or login to continue shopping with us!</p>
                <div class="btn-group">
                    <button onclick="window.location.href='login.php'" class="btn-modal btn-login">Login Now</button>
                    <button onclick="window.location.href='register.php'" class="btn-modal btn-register">Create Account</button>
                    <button onclick="closeLoginModal()" class="btn-modal btn-cancel">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal-overlay">
        <div class="success-modal">
            <div class="modal-header success">
                <span class="close-modal" onclick="closeSuccessModal()">&times;</span>
                <div class="modal-icon">✅</div>
                <h3>Added to Cart!</h3>
                <p>Your item has been successfully added</p>
            </div>
            <div class="modal-body">
                <div class="item-details">
                    <div class="item-name" id="successItemName">Item Name</div>
                    <div class="item-price" id="successItemPrice">$0.00</div>
                </div>
                <div class="btn-group">
                    <button onclick="goToCart()" class="btn-modal btn-cart">View Cart 🛒</button>
                    <button onclick="closeSuccessModal()" class="btn-modal btn-continue">Continue Shopping</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php" class="active">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>

                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Menu Title Section -->
    <div class="container">
        <div class="menu-title">
            <h2>Our Menu</h2>
            <p>Discover our exquisite selection of dishes and beverages</p>
            <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
                <div class="warning-banner">
                    🎯 Please login or create an account to start ordering! 🎯
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Menu Content -->
    <div class="container">
        <!-- Fish Section -->
        <section class="menu-category">
            <h3>🐟 Fish & Seafood</h3>
            <table class="menu-table">
                <thead>
                    <tr>
                        <th>Dish Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Grilled Salmon Fillet</strong> <em>(Popular)</em></td>
                        <td>Fresh Atlantic salmon grilled to perfection with lemon butter sauce</em></td>
                        <td class="price">$28.99</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Grilled Salmon Fillet', 28.99)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                    <tr>
                        <td><strong>Pan-Seared Sea Bass</strong></td>
                        <td>Delicate white fish with herbs, garlic, and white wine reduction</em></td>
                        <td class="price">$32.50</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Pan-Seared Sea Bass', 32.50)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                    <tr>
                        <td><strong>Shrimp Scampi</strong></td>
                        <td>Succulent shrimp in garlic, white wine, and butter sauce over pasta</em></td>
                        <td class="price">$26.99</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Shrimp Scampi', 26.99)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <!-- Meat Section -->
        <section class="menu-category">
            <h3>🥩 Meat & Poultry</h3>
            <table class="menu-table">
                <thead>
                    <tr>
                        <th>Dish Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Wagyu Beef Steak</strong> <em>(Signature Dish)</em></td>
                        <td>Premium Japanese Wagyu beef cooked to perfection with truffle mash</em></td>
                        <td class="price">$85.00</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Wagyu Beef Steak', 85.00)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                    <tr>
                        <td><strong>Herb-Crusted Lamb Chops</strong> <em>(Chef's Special)</em></td>
                        <td>Tender lamb chops with rosemary and garlic crust, served with mint sauce</em></td>
                        <td class="price">$42.00</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Herb-Crusted Lamb Chops', 42.00)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <!-- Vegetarian Section -->
        <section class="menu-category">
            <h3>🥗 Vegetarian & Pasta</h3>
            <table class="menu-table">
                <thead>
                    <tr>
                        <th>Dish Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Wild Mushroom Risotto</strong> <em>(Vegetarian)</em></td>
                        <td>Creamy risotto with forest mushrooms and truffle oil</em></td>
                        <td class="price">$22.50</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Wild Mushroom Risotto', 22.50)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <!-- Beverages Section -->
        <section class="menu-category">
            <h3>🥂 Beverages & Drinks</h3>
            <table class="menu-table">
                <thead>
                    <tr>
                        <th>Drink Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Champagne - Moët & Chandon</strong> <em>(Premium)</em></td>
                        <td>Premium French champagne, perfect for celebrations</em></td>
                        <td class="price">$89.00</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Champagne - Moët & Chandon', 89.00)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                    <tr>
                        <td><strong>Fresh Orange Juice</strong> <em>(Freshly Squeezed)</em></td>
                        <td>Freshly squeezed orange juice, 100% natural</em></td>
                        <td class="price">$6.99</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Fresh Orange Juice', 6.99)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <!-- Desserts Section -->
        <section class="menu-category">
            <h3>🍰 Desserts</h3>
            <table class="menu-table">
                <thead>
                    <tr>
                        <th>Dessert Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><strong>Chocolate Lava Cake</strong> <em>(Best Seller)</em></td>
                        <td>Warm chocolate cake with a molten center, served with vanilla ice cream</em></td>
                        <td class="price">$12.99</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Chocolate Lava Cake', 12.99)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                    <tr>
                        <td><strong>Tiramisu</strong> <em>(Italian Classic)</em></td>
                        <td>Classic Italian dessert with coffee-soaked ladyfingers and mascarpone</em></td>
                        <td class="price">$11.99</em></td>
                        <td><button onclick="checkLoginAndAddToCart('Tiramisu', 11.99)" class="btn btn-secondary">Add to Cart</button></em></td>
                    </tr>
                </tbody>
            </table>
        </section>

        <!-- Special Offers -->
        <section class="special-offer">
            <h3>🎉 Special Offers This Week 🎉</h3>
            <p>Get 20% discount on all beverages with any main course order</p>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                <a href="order.php" class="btn btn-secondary">Place an Order Now</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary">Login to Order</a>
                <a href="register.php" class="btn btn-secondary" style="margin-left: 1rem;">Create Account</a>
            <?php endif; ?>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="order.php">Place Order</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: info@m2hotel.com</p>
                <p>Phone: 0787820195 / 3345</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Variables to store current item
        let currentItemName = '';
        let currentItemPrice = 0;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
        });

        function checkLoginAndAddToCart(itemName, price) {
            if (!isLoggedIn) {
                showLoginModal();
                return false;
            }
            
            // Store current item details
            currentItemName = itemName;
            currentItemPrice = price;
            
            // Add to cart
            addToCartAndShowSuccess(itemName, price);
        }

        function showLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        function showSuccessModal(itemName, price) {
            document.getElementById('successItemName').innerHTML = itemName;
            document.getElementById('successItemPrice').innerHTML = '$' + price.toFixed(2);
            document.getElementById('successModal').style.display = 'flex';
            
            // Auto close after 3 seconds
            setTimeout(function() {
                closeSuccessModal();
            }, 3000);
        }

        function closeSuccessModal() {
            document.getElementById('successModal').style.display = 'none';
        }

        function addToCartAndShowSuccess(itemName, price) {
            // Create cart item
            const cartItem = {
                name: itemName,
                price: parseFloat(price),
                quantity: 1,
                type: 'food',
                dateAdded: new Date().toISOString()
            };
            
            // Add to cart
            addToCart(cartItem);
            
            // Show success modal
            showSuccessModal(itemName, price);
        }

        function goToCart() {
            window.location.href = 'cart.php';
        }

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function saveCart(cart) {
            localStorage.setItem('hotelCart', JSON.stringify(cart));
            updateCartCount();
        }

        function addToCart(item) {
            const cart = getCart();
            const itemId = item.name + '_' + Date.now();
            cart[itemId] = item;
            saveCart(cart);
            updateCartCount();
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            const successModal = document.getElementById('successModal');
            if (event.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (event.target === successModal) {
                successModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>