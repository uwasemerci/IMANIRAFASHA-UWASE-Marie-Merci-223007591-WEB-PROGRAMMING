<?php
session_start();
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited contact page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Modern Popup Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .login-modal, .success-modal {
            background: white;
            border-radius: 20px;
            text-align: center;
            max-width: 450px;
            width: 90%;
            padding: 0;
            overflow: hidden;
            animation: slideUp 0.4s ease;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .modal-header {
            padding: 30px 30px 20px;
            text-align: center;
        }
        
        .modal-header.login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .modal-header.success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .modal-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .modal-header h3 {
            font-size: 28px;
            margin: 0 0 10px;
        }
        
        .modal-header p {
            font-size: 16px;
            margin: 0;
            opacity: 0.95;
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }
        
        .btn-modal {
            padding: 12px 25px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-modal:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-register {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .btn-cancel {
            background: #e0e0e0;
            color: #666;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 28px;
            cursor: pointer;
            color: white;
            opacity: 0.8;
            transition: opacity 0.2s;
        }
        
        .close-modal:hover {
            opacity: 1;
        }
        
        .contact-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            margin: 40px 0;
        }
        
        .contact-info-section {
            background: #f8f9fa;
            padding: 30px;
            border-radius: 15px;
        }
        
        .contact-info-section h3 {
            color: #e67e22;
            margin-bottom: 25px;
            font-size: 1.8rem;
        }
        
        .contact-info-item {
            margin-bottom: 25px;
        }
        
        .contact-info-item h4 {
            color: #333;
            margin-bottom: 10px;
            font-size: 1.2rem;
        }
        
        .contact-info-item p {
            color: #666;
            line-height: 1.6;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 10px;
        }
        
        .social-links a {
            display: inline-block;
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
            line-height: 40px;
            border-radius: 50%;
            text-decoration: none;
            transition: transform 0.3s;
        }
        
        .social-links a:hover {
            transform: translateY(-3px);
        }
        
        .contact-form-section {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        .contact-form-section h3 {
            color: #e67e22;
            margin-bottom: 25px;
            font-size: 1.8rem;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #e67e22;
            outline: none;
        }
        
        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }
        
        .form-submit {
            background: linear-gradient(135deg, #e67e22 0%, #f39c12 100%);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .form-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(230,126,34,0.4);
        }
        
        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: center;
            padding: 50px 0;
        }
        
        .about-text h3 {
            color: #e67e22;
            margin-bottom: 20px;
            font-size: 1.8rem;
        }
        
        .about-text p {
            color: #666;
            line-height: 1.8;
            margin-bottom: 15px;
        }
        
        .placeholder-box {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            width: 100%;
            height: 300px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 15px;
            font-size: 80px;
            color: white;
        }
        
        .history-section {
            background: #f8f9fa;
            padding: 50px;
            border-radius: 15px;
            margin: 40px 0;
        }
        
        .timeline {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 25px;
        }
        
        .timeline-item {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        
        .timeline-item:hover {
            transform: translateY(-5px);
        }
        
        .timeline-item h4 {
            color: #e67e22;
            margin-bottom: 10px;
        }
        
        .timeline-item p {
            color: #666;
            line-height: 1.6;
        }
        
        .cart-icon-wrapper {
            position: relative;
            margin-left: 20px;
        }
        
        .cart-icon {
            position: relative;
            display: inline-block;
            font-size: 24px;
            text-decoration: none;
            color: #333;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -12px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .contact-container {
                grid-template-columns: 1fr;
            }
            
            .about-content {
                grid-template-columns: 1fr;
            }
            
            .timeline {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Login Required Modal -->
    <div id="loginModal" class="modal-overlay">
        <div class="login-modal">
            <div class="modal-header login">
                <span class="close-modal" onclick="closeLoginModal()">&times;</span>
                <div class="modal-icon">🔐</div>
                <h3>Login Required</h3>
                <p>Please sign in to send us a message</p>
            </div>
            <div class="modal-body">
                <p style="color: #666; margin-bottom: 20px;">Create an account or login to send us a message!</p>
                <div class="btn-group">
                    <button onclick="window.location.href='login.php'" class="btn-modal btn-login">Login Now</button>
                    <button onclick="window.location.href='register.php'" class="btn-modal btn-register">Create Account</button>
                    <button onclick="closeLoginModal()" class="btn-modal btn-cancel">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal-overlay">
        <div class="success-modal">
            <div class="modal-header success">
                <span class="close-modal" onclick="closeSuccessModal()">&times;</span>
                <div class="modal-icon">✅</div>
                <h3>Message Sent!</h3>
                <p>We'll get back to you soon</p>
            </div>
            <div class="modal-body">
                <div class="item-details" style="background: #f8f9fa; padding: 15px; border-radius: 12px; margin-bottom: 20px;">
                    <div class="item-name" style="font-size: 18px; font-weight: bold; color: #333;" id="successName">Thank you!</div>
                    <div class="item-price" style="font-size: 14px; color: #666; margin-top: 5px;" id="successMessage">Your message has been received</div>
                </div>
                <div class="btn-group">
                    <button onclick="closeSuccessModal()" class="btn-modal btn-continue">Continue Browsing</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php" class="active">Contact Us</a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>

                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Contact Title Section -->
    <div class="container">
        <div class="contact-title">
            <h2>Contact Us</h2>
            <p>We'd love to hear from you. Get in touch with us today!</p>
            <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
                <div class="warning-banner" style="background: linear-gradient(135deg, #ffe259 0%, #ffa751 100%); color: #fff; padding: 12px; text-align: center; margin-top: 20px; border-radius: 10px; font-weight: bold; animation: pulse 2s infinite;">
                    🎯 Please login or create an account to send us a message! 🎯
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Contact Content -->
    <div class="container">
        <div class="contact-container">
            <!-- Contact Information -->
            <div class="contact-info-section">
                <h3>Get In Touch</h3>

                <div class="contact-info-item">
                    <h4>📍 Address</h4>
                    <p>
                        M<sup>2</sup> Hotel<br>
                        West-Rubavu<br>
                        Rwanda
                    </p>
                </div>

                <div class="contact-info-item">
                    <h4>📞 Phone</h4>
                    <p>
                        +250 793 732 248<br>
                        +250 787820195<br>
                        +250 788 123 456
                    </p>
                </div>

                <div class="contact-info-item">
                    <h4>✉️ Email</h4>
                    <p>
                        info@m2hotel.com<br>
                        reservations@m2hotel.com
                    </p>
                </div>

                <div class="contact-info-item">
                    <h4>🕐 Hours</h4>
                    <p>
                        Monday - Thursday: 10:00 AM - 11:00 PM<br>
                        Friday - Saturday: 10:00 AM - 12:00 AM<br>
                        Sunday: 10:00 AM - 10:00 PM
                    </p>
                </div>

                <div class="contact-info-item">
                    <h4>Follow Us</h4>
                    <div class="social-links">
                        <a href="#" title="Facebook">f</a>
                        <a href="#" title="Twitter">𝕏</a>
                        <a href="#" title="Instagram">📷</a>
                        <a href="#" title="LinkedIn">in</a>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contact-form-section">
                <h3>Send us a Message</h3>
                <form id="contactForm" onsubmit="return handleContactSubmit(event)">
                    <div class="form-group">
                        <label for="fullname">Your Name *</label>
                        <input type="text" id="fullname" name="fullname" placeholder="Enter your name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" placeholder="your@email.com" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" id="phone" name="phone" placeholder="0787820195 / 3345" required>
                    </div>

                    <div class="form-group">
                        <label for="location">Location *</label>
                        <input type="text" id="location" name="location" placeholder="Your city or location" required>
                    </div>

                    <div class="form-group">
                        <label for="message">Message *</label>
                        <textarea id="message" name="message" placeholder="Type your message here (minimum 10 characters)" required></textarea>
                    </div>

                    <button type="submit" class="form-submit">Send Message 📧</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Location/Map Section -->
    <div class="container">
        <section class="about-content">
            <div class="about-text">
                <h3>Visit Us</h3>
                <p>
                    Our luxury hotel is located in the heart of Rubavu, easily accessible from major transportation hubs. 
                    Visit us to experience firsthand the elegance and hospitality that M<sup>2</sup> Hotel is known for.
                </p>
                <p>
                    Whether you're planning a special celebration, a romantic dinner, or a casual meal with friends and family, 
                    our team is ready to make your visit unforgettable.
                </p>
                <p>
                    <strong>Parking:</strong> Complimentary valet parking for hotel guests and restaurant patrons.<br>
                    <strong>Wheelchair Accessible:</strong> Yes, we have full accessibility facilities.<br>
                    <strong>Reservations:</strong> Recommended for dinner service.
                </p>
            </div>
            <div class="about-image">
                <div class="placeholder-box">📍 M<sup>2</sup> Hotel</div>
            </div>
        </section>
    </div>

    <!-- FAQ Section -->
    <div class="container">
        <section class="history-section">
            <h3 style="text-align: center; color: #2c3e50; margin-bottom: 2rem;">Frequently Asked Questions</h3>
            <div class="timeline">
                <div class="timeline-item">
                    <h4>What are your operating hours?</h4>
                    <p>
                        We're open Monday-Thursday 10 AM - 11 PM, Friday-Saturday 10 AM - 12 AM, and Sunday 10 AM - 10 PM. 
                        Holiday hours may vary.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>Do you offer reservations?</h4>
                    <p>
                        Yes! Reservations are recommended, especially for dinner service and weekends. Call us or book online through our website.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>Can you accommodate dietary restrictions?</h4>
                    <p>
                        Absolutely! Please inform us of any dietary preferences or allergies when making your reservation or 
                        ordering, and our chef will be happy to create a special meal for you.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>Do you offer catering services?</h4>
                    <p>
                        Yes, we provide catering for private events, corporate functions, and special occasions. 
                        Contact us for more details and pricing.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>What payment methods do you accept?</h4>
                    <p>
                        We accept all major credit cards, debit cards, and mobile money. For room charges, 
                        we also accept direct bank transfers.
                    </p>
                </div>
                <div class="timeline-item">
                    <h4>Do you have parking available?</h4>
                    <p>
                        Yes, complimentary valet parking is available for hotel guests and restaurant patrons. 
                        Self-parking is also available.
                    </p>
                </div>
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="order.php">Place Order</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: info@m2hotel.com</p>
                <p>Phone: +250 787820195</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
        });

        function handleContactSubmit(event) {
            event.preventDefault();
            
            if (!isLoggedIn) {
                showLoginModal();
                return false;
            }
            
            // Get form data
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const location = document.getElementById('location').value;
            const message = document.getElementById('message').value;
            
            // Validate form
            if (!fullname || !email || !phone || !location || !message) {
                alert('Please fill in all fields');
                return false;
            }
            
            if (message.length < 10) {
                alert('Message must be at least 10 characters long');
                return false;
            }
            
            // Create contact object
            const contact = {
                id: 'MSG-' + Date.now(),
                name: fullname,
                email: email,
                phone: phone,
                location: location,
                message: message,
                date: new Date().toISOString(),
                status: 'pending'
            };
            
            // Save to localStorage
            saveContactMessage(contact);
            
            // Show success modal
            showSuccessModal(fullname);
            
            // Reset form
            document.getElementById('contactForm').reset();
            
            return false;
        }
        
        function saveContactMessage(contact) {
            let messages = JSON.parse(localStorage.getItem('contactMessages') || '[]');
            messages.push(contact);
            localStorage.setItem('contactMessages', JSON.stringify(messages));
            
            // You could also send to backend here via AJAX
            console.log('Message saved:', contact);
        }

        function showLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        function showSuccessModal(name) {
            document.getElementById('successName').innerHTML = 'Thank you, ' + name + '!';
            document.getElementById('successMessage').innerHTML = 'Your message has been received. We\'ll get back to you soon!';
            document.getElementById('successModal').style.display = 'flex';
            
            // Auto close after 3 seconds
            setTimeout(function() {
                closeSuccessModal();
            }, 3000);
        }

        function closeSuccessModal() {
            document.getElementById('successModal').style.display = 'none';
        }

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function saveCart(cart) {
            localStorage.setItem('hotelCart', JSON.stringify(cart));
            updateCartCount();
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            const successModal = document.getElementById('successModal');
            if (event.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (event.target === successModal) {
                successModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>