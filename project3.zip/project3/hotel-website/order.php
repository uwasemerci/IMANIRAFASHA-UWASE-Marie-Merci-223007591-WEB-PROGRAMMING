<?php
session_start();
// Log page visit
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited order page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Modern Popup Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .login-modal, .success-modal {
            background: white;
            border-radius: 20px;
            text-align: center;
            max-width: 450px;
            width: 90%;
            padding: 0;
            overflow: hidden;
            animation: slideUp 0.4s ease;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .modal-header {
            padding: 30px 30px 20px;
            text-align: center;
        }
        
        .modal-header.login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .modal-header.success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .modal-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .modal-header h3 {
            font-size: 28px;
            margin: 0 0 10px;
        }
        
        .modal-header p {
            font-size: 16px;
            margin: 0;
            opacity: 0.95;
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }
        
        .btn-modal {
            padding: 12px 25px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-modal:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-register {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .btn-cancel {
            background: #e0e0e0;
            color: #666;
        }
        
        .btn-cart {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .btn-continue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 28px;
            cursor: pointer;
            color: white;
            opacity: 0.8;
            transition: opacity 0.2s;
        }
        
        .close-modal:hover {
            opacity: 1;
        }
        
        .warning-banner {
            background: linear-gradient(135deg, #ffe259 0%, #ffa751 100%);
            color: #fff;
            padding: 12px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: bold;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }
        
        .order-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #333;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: #e67e22;
            outline: none;
        }
        
        .form-submit {
            background: linear-gradient(135deg, #e67e22 0%, #f39c12 100%);
            color: white;
            padding: 14px 30px;
            border: none;
            border-radius: 50px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .form-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(230,126,34,0.4);
        }
        
        fieldset {
            margin-bottom: 2rem;
        }
        
        legend {
            font-size: 1.3rem;
            color: #e67e22;
            margin-bottom: 1rem;
            font-weight: bold;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #f39c12;
        }
        
        .cart-icon-wrapper {
            position: relative;
            margin-left: 20px;
        }
        
        .cart-icon {
            position: relative;
            display: inline-block;
            font-size: 24px;
            text-decoration: none;
            color: #333;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -12px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Login Required Modal -->
    <div id="loginModal" class="modal-overlay">
        <div class="login-modal">
            <div class="modal-header login">
                <span class="close-modal" onclick="closeLoginModal()">&times;</span>
                <div class="modal-icon">🔐</div>
                <h3>Login Required</h3>
                <p>Please sign in to place your order</p>
            </div>
            <div class="modal-body">
                <p style="color: #666; margin-bottom: 20px;">Create an account or login to continue with your order!</p>
                <div class="btn-group">
                    <button onclick="window.location.href='login.php'" class="btn-modal btn-login">Login Now</button>
                    <button onclick="window.location.href='register.php'" class="btn-modal btn-register">Create Account</button>
                    <button onclick="closeLoginModal()" class="btn-modal btn-cancel">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal-overlay">
        <div class="success-modal">
            <div class="modal-header success">
                <span class="close-modal" onclick="closeSuccessModal()">&times;</span>
                <div class="modal-icon">✅</div>
                <h3>Order Placed Successfully!</h3>
                <p>Your order has been received</p>
            </div>
            <div class="modal-body">
                <div class="item-details" style="background: #f8f9fa; padding: 15px; border-radius: 12px; margin-bottom: 20px;">
                    <div class="item-name" id="successItemName" style="font-size: 18px; font-weight: bold; color: #333;">Order Details</div>
                    <div class="item-price" id="successItemPrice" style="font-size: 20px; font-weight: bold; color: #e67e22; margin-top: 5px;"></div>
                </div>
                <div class="btn-group">
                    <button onclick="window.location.href='index.php'" class="btn-modal btn-cart">Return Home 🏠</button>
                    <button onclick="closeSuccessModal()" class="btn-modal btn-continue">Continue Shopping</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php" class="active">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>

                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Order Title Section -->
    <div class="container">
        <div class="order-title">
            <h2>Place Your Order</h2>
            <p>Order delicious food and drinks online</p>
            <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
                <div class="warning-banner">
                    🎯 Please login or create an account to place your order! 🎯
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Order Form -->
    <div class="container">
        <div class="order-container">
            <form id="orderForm" onsubmit="return handleOrderSubmit(event)">
                <!-- Customer Information -->
                <fieldset>
                    <legend>👤 Customer Information</legend>

                    <div class="form-group">
                        <label for="fullname">Full Name *</label>
                        <input type="text" id="fullname" name="fullname" placeholder="Enter your full name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" placeholder="your@email.com" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" id="phone" name="phone" placeholder="0787820195 / 3345" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Delivery Address *</label>
                        <textarea id="address" name="address" rows="3" placeholder="Enter your full address" required></textarea>
                    </div>
                </fieldset>

                <!-- Menu Selection -->
                <fieldset>
                    <legend>🍽️ Select Menu Item</legend>

                    <div class="form-group">
                        <label for="menu">Choose Your Dish *</label>
                        <select id="menu" name="menu" required>
                            <option value="">-- Select a menu item --</option>
                            <optgroup label="🐟 Fish & Seafood">
                                <option value="Grilled Salmon Fillet|28.99">Grilled Salmon Fillet - $28.99</option>
                                <option value="Pan-Seared Sea Bass|32.50">Pan-Seared Sea Bass - $32.50</option>
                                <option value="Shrimp Scampi|26.99">Shrimp Scampi - $26.99</option>
                                <option value="Lobster Tail|42.00">Lobster Tail - $42.00</option>
                            </optgroup>
                            <optgroup label="🥩 Meat & Poultry">
                                <option value="Wagyu Beef Steak|85.00">Wagyu Beef Steak - $85.00</option>
                                <option value="Herb-Crusted Lamb Chops|42.00">Herb-Crusted Lamb Chops - $42.00</option>
                                <option value="Grilled Chicken Breast|24.99">Grilled Chicken Breast - $24.99</option>
                                <option value="Duck Confit|38.50">Duck Confit - $38.50</option>
                            </optgroup>
                            <optgroup label="🥗 Vegetarian & Pasta">
                                <option value="Wild Mushroom Risotto|22.50">Wild Mushroom Risotto - $22.50</option>
                                <option value="Fettuccine Alfredo|19.99">Fettuccine Alfredo - $19.99</option>
                                <option value="Spaghetti Aglio e Olio|16.50">Spaghetti Aglio e Olio - $16.50</option>
                            </optgroup>
                            <optgroup label="🥂 Beverages">
                                <option value="Fresh Orange Juice|6.99">Fresh Orange Juice - $6.99</option>
                                <option value="Strawberry Banana Smoothie|7.99">Strawberry Banana Smoothie - $7.99</option>
                                <option value="Champagne - Moët & Chandon|89.00">Champagne - Moët & Chandon - $89.00</option>
                                <option value="Espresso|4.50">Espresso - $4.50</option>
                            </optgroup>
                            <optgroup label="🍰 Desserts">
                                <option value="Chocolate Lava Cake|12.99">Chocolate Lava Cake - $12.99</option>
                                <option value="Tiramisu|11.99">Tiramisu - $11.99</option>
                                <option value="Crème Brûlée|11.99">Crème Brûlée - $11.99</option>
                            </optgroup>
                        </select>
                    </div>
                </fieldset>

                <!-- Delivery Details -->
                <fieldset>
                    <legend>📅 Delivery Details</legend>

                    <div class="form-group">
                        <label for="date">Preferred Delivery Date *</label>
                        <input type="date" id="date" name="date" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Quantity *</label>
                        <input type="number" id="quantity" name="quantity" min="1" max="20" value="1" required>
                    </div>
                </fieldset>

                <!-- Submit Button -->
                <button type="submit" class="form-submit">Place Order 🛒</button>
            </form>
        </div>
    </div>

    <!-- Information Section -->
    <div class="container">
        <section class="special-offer">
            <h3>🎉 Special Offer! 🎉</h3>
            <p>Get 20% discount on all beverages with any main course order</p>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="order.php">Place Order</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: info@m2hotel.com</p>
                <p>Phone: 0787820195 / 3345</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
        });

        function handleOrderSubmit(event) {
            event.preventDefault();
            
            if (!isLoggedIn) {
                showLoginModal();
                return false;
            }
            
            // Get form data
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const address = document.getElementById('address').value;
            const menuSelect = document.getElementById('menu');
            const selectedOption = menuSelect.options[menuSelect.selectedIndex];
            const menuValue = menuSelect.value;
            const date = document.getElementById('date').value;
            const quantity = document.getElementById('quantity').value;
            
            // Validate form
            if (!fullname || !email || !phone || !address || !menuValue || !date) {
                alert('Please fill in all required fields');
                return false;
            }
            
            // Parse menu item and price
            const [itemName, itemPrice] = menuValue.split('|');
            const totalPrice = parseFloat(itemPrice) * parseInt(quantity);
            
            // Create order object
            const order = {
                orderId: 'ORD-' + Date.now(),
                customer: {
                    name: fullname,
                    email: email,
                    phone: phone,
                    address: address
                },
                item: {
                    name: itemName,
                    price: parseFloat(itemPrice),
                    quantity: parseInt(quantity)
                },
                deliveryDate: date,
                total: totalPrice,
                orderDate: new Date().toISOString()
            };
            
            // Save order to localStorage
            saveOrder(order);
            
            // Add to cart as well
            const cartItem = {
                name: itemName,
                price: parseFloat(itemPrice),
                quantity: parseInt(quantity),
                type: 'food',
                orderDetails: order,
                dateAdded: new Date().toISOString()
            };
            addToCart(cartItem);
            
            // Show success modal
            showSuccessModal(itemName, totalPrice);
            
            // Reset form
            document.getElementById('orderForm').reset();
            
            return false;
        }
        
        function saveOrder(order) {
            let orders = JSON.parse(localStorage.getItem('hotelOrders') || '[]');
            orders.push(order);
            localStorage.setItem('hotelOrders', JSON.stringify(orders));
        }

        function showLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        function showSuccessModal(itemName, totalPrice) {
            document.getElementById('successItemName').innerHTML = itemName;
            document.getElementById('successItemPrice').innerHTML = 'Total: $' + totalPrice.toFixed(2);
            document.getElementById('successModal').style.display = 'flex';
            
            // Auto close after 4 seconds
            setTimeout(function() {
                closeSuccessModal();
            }, 4000);
        }

        function closeSuccessModal() {
            document.getElementById('successModal').style.display = 'none';
        }

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function saveCart(cart) {
            localStorage.setItem('hotelCart', JSON.stringify(cart));
            updateCartCount();
        }

        function addToCart(item) {
            const cart = getCart();
            const itemId = item.name + '_' + Date.now();
            cart[itemId] = item;
            saveCart(cart);
            updateCartCount();
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            const successModal = document.getElementById('successModal');
            if (event.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (event.target === successModal) {
                successModal.style.display = 'none';
            }
        }
        
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('date').min = today;
    </script>
</body>
</html>