<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php
    require_once 'php/db_connection.php';
    logUserActivity('page_visit', 'Visited checkout page');
    
    // Check if cart is empty
    if (!isset($_POST['process']) && (!isset($_SESSION['cart']) || empty($_SESSION['cart']))) {
        // Check if coming from cart.php (GET request)
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            // Redirect to cart if no items
            header("Location: cart.php");
            exit;
        }
    }
    ?>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Checkout Section -->
    <div class="container">
        <div class="checkout-title">
            <h2>Checkout</h2>
            <p>Complete your order details and confirm payment</p>
        </div>
    </div>

    <!-- Checkout Content -->
    <div class="container">
        <div class="checkout-container">
            <!-- Customer Information Form -->
            <div class="checkout-form">
                <h3>Customer Information</h3>
                <form action="php/process_checkout.php" method="POST" onsubmit="return validateCheckoutForm(event)">
                    <div class="form-group">
                        <label for="fullname">Full Name *</label>
                        <input type="text" id="fullname" name="fullname" placeholder="Enter your full name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" placeholder="your@email.com" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number *</label>
                        <input type="tel" id="phone" name="phone" placeholder="+250 793 732 248" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Delivery/Room Address *</label>
                        <textarea id="address" name="address" placeholder="Enter your full address" required></textarea>
                    </div>

                    <h3 style="margin-top: 2rem;">Payment Information</h3>

                    <div class="form-group">
                        <label for="payment_method">Payment Method *</label>
                        <select id="payment_method" name="payment_method" required>
                            <option value="">-- Select Payment Method --</option>
                            <option value="Credit Card">Credit Card</option>
                            <option value="Debit Card">Debit Card</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Mobile Money">Mobile Money</option>
                            <option value="Cash on Delivery">Cash on Delivery</option>
                        </select>
                    </div>

                    <div id="card-details" style="display: none;">
                        <div class="form-group">
                            <label for="card_number">Card Number *</label>
                            <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19">
                        </div>

                        <div class="form-group-inline">
                            <div class="form-group">
                                <label for="expiry">Expiry Date *</label>
                                <input type="text" id="expiry" name="expiry" placeholder="MM/YY" maxlength="5">
                            </div>
                            <div class="form-group">
                                <label for="cvv">CVV *</label>
                                <input type="text" id="cvv" name="cvv" placeholder="123" maxlength="3">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="special_requests">Special Requests / Notes</label>
                        <textarea id="special_requests" name="special_requests" placeholder="Any special instructions..."></textarea>
                    </div>

                    <!-- Hidden fields for cart data -->
                    <input type="hidden" id="cart_items" name="cart_items" value="">
                    <input type="hidden" id="total_amount" name="total_amount" value="">

                    <button type="submit" class="form-submit">Complete Purchase</button>
                </form>
            </div>

            <!-- Order Summary -->
            <div class="checkout-summary">
                <h3>Order Summary</h3>
                <div class="summary-items" id="summaryItems">
                    <!-- Items will be loaded here by JavaScript -->
                </div>
                <div class="summary-item">
                    <span>Subtotal:</span>
                    <span id="summarySubtotal">$0.00</span>
                </div>
                <div class="summary-item">
                    <span>Tax (10%):</span>
                    <span id="summaryTax">$0.00</span>
                </div>
                <div class="summary-item total">
                    <span>Total:</span>
                    <span id="summaryTotal">$0.00</span>
                </div>
                <a href="cart.php" class="btn btn-secondary" style="width: 100%; text-align: center; margin-top: 1rem;">Edit Cart</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="cart.php">Shopping Cart</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: m2@info.rw</p>
                <p>Phone: +250 793 732 248</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Load cart data on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateCartCount();
            loadCheckoutSummary();
            setupPaymentMethod();
        });

        function loadCheckoutSummary() {
            const cart = getCart();
            const summaryItems = document.getElementById('summaryItems');
            summaryItems.innerHTML = '';

            let subtotal = 0;

            for (const [itemName, itemData] of Object.entries(cart)) {
                const price = parseFloat(itemData.price);
                const quantity = itemData.quantity;
                const itemTotal = price * quantity;
                subtotal += itemTotal;

                const itemDiv = document.createElement('div');
                itemDiv.className = 'summary-item-detail';
                itemDiv.innerHTML = `
                    <span>${itemName} <small>x${quantity}</small></span>
                    <span>$${itemTotal.toFixed(2)}</span>
                `;
                summaryItems.appendChild(itemDiv);
            }

            const tax = subtotal * 0.1;
            const total = subtotal + tax;

            document.getElementById('summarySubtotal').textContent = '$' + subtotal.toFixed(2);
            document.getElementById('summaryTax').textContent = '$' + tax.toFixed(2);
            document.getElementById('summaryTotal').textContent = '$' + total.toFixed(2);

            // Store total for submission
            localStorage.setItem('checkoutTotal', total.toFixed(2));
        }

        function setupPaymentMethod() {
            const paymentSelect = document.getElementById('payment_method');
            const cardDetails = document.getElementById('card-details');

            paymentSelect.addEventListener('change', function() {
                if (this.value === 'Credit Card' || this.value === 'Debit Card') {
                    cardDetails.style.display = 'block';
                } else {
                    cardDetails.style.display = 'none';
                }
            });
        }

        function validateCheckoutForm(event) {
            const fullname = document.getElementById('fullname').value.trim();
            const email = document.getElementById('email').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const address = document.getElementById('address').value.trim();
            const paymentMethod = document.getElementById('payment_method').value.trim();

            let errors = [];

            if (!fullname) errors.push('Please enter your name');
            if (!email || !isValidEmail(email)) errors.push('Please enter a valid email');
            if (!phone || !isValidPhone(phone)) errors.push('Please enter a valid phone number');
            if (!address) errors.push('Please enter your address');
            if (!paymentMethod) errors.push('Please select a payment method');

            if (paymentMethod === 'Credit Card' || paymentMethod === 'Debit Card') {
                const cardNumber = document.getElementById('card_number').value.trim();
                const expiry = document.getElementById('expiry').value.trim();
                const cvv = document.getElementById('cvv').value.trim();

                if (!cardNumber || cardNumber.replace(/\s/g, '').length < 13) {
                    errors.push('Please enter a valid card number');
                }
                if (!expiry || !expiry.match(/^\d{2}\/\d{2}$/)) {
                    errors.push('Expiry date must be in MM/YY format');
                }
                if (!cvv || cvv.length !== 3) {
                    errors.push('CVV must be 3 digits');
                }
            }

            if (errors.length > 0) {
                event.preventDefault();
                showError(errors.join('\n'));
                return false;
            }

            // Populate cart data before submit
            const cart = getCart();
            const cartItems = [];
            let total = 0;

            for (const [itemName, itemData] of Object.entries(cart)) {
                const price = parseFloat(itemData.price);
                const quantity = itemData.quantity;
                cartItems.push({
                    name: itemName,
                    price: price,
                    quantity: quantity
                });
                total += (price * quantity);
            }

            // Add tax
            total = (total * 1.1).toFixed(2);

            document.getElementById('cart_items').value = JSON.stringify(cartItems);
            document.getElementById('total_amount').value = total;

            return true;
        }
    </script>
</body>
</html>
