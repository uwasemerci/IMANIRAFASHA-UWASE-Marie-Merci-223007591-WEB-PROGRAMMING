<?php
session_start();
require_once 'php/db_connection.php';
logUserActivity('page_visit', 'Visited rooms page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rooms & Conference - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Modern Popup Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 2000;
            animation: fadeIn 0.3s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        .login-modal, .success-modal {
            background: white;
            border-radius: 20px;
            text-align: center;
            max-width: 450px;
            width: 90%;
            padding: 0;
            overflow: hidden;
            animation: slideUp 0.4s ease;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        
        @keyframes slideUp {
            from {
                transform: translateY(50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .modal-header {
            padding: 30px 30px 20px;
            text-align: center;
        }
        
        .modal-header.login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .modal-header.success {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .modal-icon {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .modal-header h3 {
            font-size: 28px;
            margin: 0 0 10px;
        }
        
        .modal-header p {
            font-size: 16px;
            margin: 0;
            opacity: 0.95;
        }
        
        .modal-body {
            padding: 30px;
        }
        
        .item-details {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        
        .item-name {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }
        
        .item-price {
            font-size: 24px;
            font-weight: bold;
            color: #e67e22;
            margin-top: 5px;
        }
        
        .btn-group {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 20px;
        }
        
        .btn-modal {
            padding: 12px 25px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .btn-modal:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-register {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .btn-cancel {
            background: #e0e0e0;
            color: #666;
        }
        
        .btn-cart {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
        }
        
        .btn-continue {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 28px;
            cursor: pointer;
            color: white;
            opacity: 0.8;
            transition: opacity 0.2s;
        }
        
        .close-modal:hover {
            opacity: 1;
        }
        
        .warning-banner {
            background: linear-gradient(135deg, #ffe259 0%, #ffa751 100%);
            color: #fff;
            padding: 12px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: bold;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }
        
        .room-price {
            font-size: 1.25rem;
            font-weight: bold;
            color: #e67e22;
            margin: 10px 0;
        }
        
        .price-display {
            margin: 15px 0;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
            text-align: center;
            font-size: 1.1rem;
        }
        
        .cart-icon-wrapper {
            position: relative;
            margin-left: 20px;
        }
        
        .cart-icon {
            position: relative;
            display: inline-block;
            font-size: 24px;
            text-decoration: none;
            color: #333;
        }
        
        .cart-count {
            position: absolute;
            top: -8px;
            right: -12px;
            background: #e74c3c;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- Login Required Modal -->
    <div id="loginModal" class="modal-overlay">
        <div class="login-modal">
            <div class="modal-header login">
                <span class="close-modal" onclick="closeLoginModal()">&times;</span>
                <div class="modal-icon">🔐</div>
                <h3>Login Required</h3>
                <p>Please sign in to make a reservation</p>
            </div>
            <div class="modal-body">
                <p style="color: #666; margin-bottom: 20px;">Create an account or login to continue with your reservation!</p>
                <div class="btn-group">
                    <button onclick="window.location.href='login.php'" class="btn-modal btn-login">Login Now</button>
                    <button onclick="window.location.href='register.php'" class="btn-modal btn-register">Create Account</button>
                    <button onclick="closeLoginModal()" class="btn-modal btn-cancel">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal-overlay">
        <div class="success-modal">
            <div class="modal-header success">
                <span class="close-modal" onclick="closeSuccessModal()">&times;</span>
                <div class="modal-icon">✅</div>
                <h3>Added to Cart!</h3>
                <p>Your reservation has been added</p>
            </div>
            <div class="modal-body">
                <div class="item-details">
                    <div class="item-name" id="successItemName">Room Reservation</div>
                    <div class="item-price" id="successItemPrice">$0.00</div>
                </div>
                <div class="btn-group">
                    <button onclick="goToCart()" class="btn-modal btn-cart">View Cart 🛒</button>
                    <button onclick="closeSuccessModal()" class="btn-modal btn-continue">Continue Shopping</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php" class="active">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <li><a href="php/logout.php">Logout <span class="nav-user-badge"><?php echo htmlspecialchars(getUserInitials($_SESSION['customer_name'] ?? 'User')); ?></span></a></li>
                <?php else: ?>

                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
            <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Rooms Hero Section -->
    <div class="container">
        <div class="rooms-hero">
            <div class="rooms-hero-text">
                <h2>Rooms & Conference Spaces</h2>
                <p>Explore our hotel rooms, VIP suites, and premium conference venues. Reserve your stay or event space today.</p>
                <a href="#reserve" class="btn btn-primary">Reserve Now</a>
            </div>
            <div class="rooms-hero-image">
                <img src="images/hotelinside1.jpg" alt="Hotel room interior">
            </div>
        </div>
    </div>

    <!-- Warning Banner for Non-Logged Users -->
    <?php if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true): ?>
    <div class="container">
        <div class="warning-banner">
            🎯 Please login or create an account to make reservations! 🎯
        </div>
    </div>
    <?php endif; ?>

    <!-- Room Categories Section -->
    <div class="container">
        <section class="room-grid">
            <div class="room-card">
                <img src="images/hotelinside.jpg" alt="Deluxe Room">
                <div class="room-card-content">
                    <h4>Deluxe Rooms</h4>
                    <p>Comfortable rooms with elegant interiors, fast Wi-Fi, and city views.</p>
                    <p class="room-price">$150/night</p>
                    <button onclick="checkLoginAndAddRoomToCart('Deluxe Room', 150)" class="btn btn-primary">Add to Cart</button>
                    <a href="#reserve" class="btn btn-secondary">Reserve a Room</a>
                </div>
            </div>
            <div class="room-card">
                <img src="images/hotel1.jpg" alt="VIP Suite">
                <div class="room-card-content">
                    <h4>VIP Suites</h4>
                    <p>Luxury suites with private lounges, premium bedding, and executive service.</p>
                    <p class="room-price">$350/night</p>
                    <button onclick="checkLoginAndAddRoomToCart('VIP Suite', 350)" class="btn btn-primary">Add to Cart</button>
                    <a href="#reserve" class="btn btn-secondary">Book VIP Suite</a>
                </div>
            </div>
            <div class="room-card">
                <img src="images/conf1.jpg" alt="Conference Room">
                <div class="room-card-content">
                    <h4>Conference Rooms</h4>
                    <p>Modern conference spaces ideal for meetings, workshops, and events.</p>
                    <p class="room-price">$500/day</p>
                    <button onclick="checkLoginAndAddRoomToCart('Conference Room', 500)" class="btn btn-primary">Add to Cart</button>
                    <a href="#reserve" class="btn btn-secondary">Reserve Conference</a>
                </div>
            </div>
            <div class="room-card">
                <img src="images/VVIP2.jpg" alt="Conference Hall">
                <div class="room-card-content">
                    <h4>Event Venues</h4>
                    <p>Spacious event halls for banquets, weddings, and business functions.</p>
                    <p class="room-price">$1000/day</p>
                    <button onclick="checkLoginAndAddRoomToCart('Event Space', 1000)" class="btn btn-primary">Add to Cart</button>
                    <a href="#reserve" class="btn btn-secondary">Book Event Space</a>
                </div>
            </div>
        </section>
    </div>

    <!-- Reservation Form -->
    <div class="container">
        <section class="reserve-section" id="reserve">
            <div class="reserve-header">
                <h2>Book Your Room or Conference Space</h2>
                <p>Complete the form and our reservations team will contact you to confirm availability.</p>
            </div>
            <div class="reserve-grid">
                <div class="reserve-info">
                    <h3>Booking Options</h3>
                    <ul>
                        <li>Standard Room - $100/night</li>
                        <li>Deluxe Room - $150/night</li>
                        <li>VIP Suite - $350/night</li>
                        <li>Conference Room - $500/day</li>
                        <li>Event Space - $1000/day</li>
                    </ul>
                    <p>All bookings include room service, free Wi-Fi, and access to our restaurant and lounge.</p>
                </div>
                <div class="reserve-form">
                    <form id="reservationForm" onsubmit="return handleReservationSubmit(event)">
                        <div class="form-group">
                            <label for="fullname">Full Name *</label>
                            <input type="text" id="fullname" name="fullname" placeholder="Enter your full name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" placeholder="your@email.com" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number *</label>
                            <input type="tel" id="phone" name="phone" placeholder="0787820195 / 3345" required>
                        </div>
                        <div class="form-group">
                            <label for="room_type">Room Type *</label>
                            <select id="room_type" name="room_type" required onchange="updateRoomPrice()">
                                <option value="">-- Select a room or conference option --</option>
                                <option value="Standard Room" data-price="100">Standard Room - $100/night</option>
                                <option value="Deluxe Room" data-price="150">Deluxe Room - $150/night</option>
                                <option value="VIP Suite" data-price="350">VIP Suite - $350/night</option>
                                <option value="Conference Room" data-price="500">Conference Room - $500/day</option>
                                <option value="Event Space" data-price="1000">Event Space - $1000/day</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="nights">Number of Nights/Days *</label>
                            <input type="number" id="nights" name="nights" min="1" max="30" value="1" required onchange="updateRoomPrice()">
                        </div>
                        <div class="form-group-inline">
                            <div class="form-group">
                                <label for="checkin_date">Check-In Date *</label>
                                <input type="date" id="checkin_date" name="checkin_date" required>
                            </div>
                            <div class="form-group">
                                <label for="checkout_date">Check-Out Date *</label>
                                <input type="date" id="checkout_date" name="checkout_date" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="guests">Number of Guests *</label>
                            <input type="number" id="guests" name="guests" min="1" max="20" value="1" required>
                        </div>
                        <div class="form-group">
                            <label for="special_requests">Special Requests</label>
                            <textarea id="special_requests" name="special_requests" placeholder="Any special requests or notes"></textarea>
                        </div>
                        <div class="price-display">
                            <strong>Total Price: $<span id="totalPrice">0</span></strong>
                        </div>
                        <button type="submit" class="form-submit">Add to Cart & Reserve</button>
                    </form>
                </div>
            </div>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="rooms.php">Rooms</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: info@m2hotel.com</p>
                <p>Phone: 0787820195 / 3345</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        // Check if user is logged in
        const isLoggedIn = <?php echo isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true ? 'true' : 'false'; ?>;
        
        // Update cart count on page load
        document.addEventListener('DOMContentLoaded', function() {
            if (isLoggedIn) {
                updateCartCount();
            }
            // Set minimum dates
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('checkin_date').min = today;
            document.getElementById('checkout_date').min = today;
        });

        function checkLoginAndAddRoomToCart(roomName, pricePerNight) {
            if (!isLoggedIn) {
                showLoginModal();
                return false;
            }
            
            const nights = prompt('How many nights/days would you like to book?', '1');
            if (nights && !isNaN(nights) && nights > 0) {
                const totalPrice = pricePerNight * parseInt(nights);
                addRoomToCartAndShowSuccess(roomName, totalPrice, nights, pricePerNight);
            } else if (nights) {
                alert('Please enter a valid number of nights/days');
            }
        }

        function addRoomToCartAndShowSuccess(roomName, totalPrice, nights, pricePerNight) {
            const cartItem = {
                name: `${roomName} (${nights} night(s))`,
                price: totalPrice,
                quantity: 1,
                type: 'room',
                details: {
                    roomType: roomName,
                    nights: nights,
                    pricePerNight: pricePerNight
                }
            };
            
            addToCart(cartItem);
            showSuccessModal(`${roomName} (${nights} nights)`, totalPrice);
        }

        function updateRoomPrice() {
            const select = document.getElementById('room_type');
            const selectedOption = select.options[select.selectedIndex];
            const pricePerNight = selectedOption.getAttribute('data-price');
            const nights = document.getElementById('nights').value;
            
            if (pricePerNight && nights) {
                const total = parseInt(pricePerNight) * parseInt(nights);
                document.getElementById('totalPrice').innerText = total;
            }
        }

        function handleReservationSubmit(event) {
            event.preventDefault();
            
            if (!isLoggedIn) {
                showLoginModal();
                return false;
            }
            
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const phone = document.getElementById('phone').value;
            const roomType = document.getElementById('room_type').value;
            const nights = document.getElementById('nights').value;
            const checkinDate = document.getElementById('checkin_date').value;
            const checkoutDate = document.getElementById('checkout_date').value;
            const guests = document.getElementById('guests').value;
            
            if (!fullname || !email || !phone || !roomType || !nights || !checkinDate || !checkoutDate) {
                alert('Please fill in all required fields');
                return false;
            }
            
            const select = document.getElementById('room_type');
            const selectedOption = select.options[select.selectedIndex];
            const pricePerNight = selectedOption.getAttribute('data-price');
            const totalPrice = parseInt(pricePerNight) * parseInt(nights);
            
            const cartItem = {
                name: `${roomType} Booking (${nights} night(s))`,
                price: totalPrice,
                quantity: 1,
                type: 'room',
                details: {
                    fullname: fullname,
                    email: email,
                    phone: phone,
                    roomType: roomType,
                    nights: nights,
                    checkinDate: checkinDate,
                    checkoutDate: checkoutDate,
                    guests: guests,
                    specialRequests: document.getElementById('special_requests').value,
                    pricePerNight: pricePerNight
                }
            };
            
            addToCart(cartItem);
            showSuccessModal(`${roomType} Booking (${nights} nights)`, totalPrice);
            
            // Reset form
            document.getElementById('reservationForm').reset();
            document.getElementById('totalPrice').innerText = '0';
            
            return false;
        }

        function showLoginModal() {
            document.getElementById('loginModal').style.display = 'flex';
        }

        function closeLoginModal() {
            document.getElementById('loginModal').style.display = 'none';
        }

        function showSuccessModal(itemName, totalPrice) {
            document.getElementById('successItemName').innerHTML = itemName;
            document.getElementById('successItemPrice').innerHTML = '$' + totalPrice.toFixed(2);
            document.getElementById('successModal').style.display = 'flex';
            
            // Auto close after 3 seconds
            setTimeout(function() {
                closeSuccessModal();
            }, 3000);
        }

        function closeSuccessModal() {
            document.getElementById('successModal').style.display = 'none';
        }

        function goToCart() {
            window.location.href = 'cart.php';
        }

        // Cart functions
        function getCart() {
            const cart = localStorage.getItem('hotelCart');
            return cart ? JSON.parse(cart) : {};
        }

        function saveCart(cart) {
            localStorage.setItem('hotelCart', JSON.stringify(cart));
            updateCartCount();
        }

        function addToCart(item) {
            const cart = getCart();
            const itemId = item.name + '_' + Date.now();
            cart[itemId] = item;
            saveCart(cart);
            updateCartCount();
        }

        function updateCartCount() {
            const cart = getCart();
            const count = Object.keys(cart).length;
            const cartCountElement = document.getElementById('cart-count');
            if (cartCountElement) {
                cartCountElement.textContent = count;
            }
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            const successModal = document.getElementById('successModal');
            if (event.target === loginModal) {
                loginModal.style.display = 'none';
            }
            if (event.target === successModal) {
                successModal.style.display = 'none';
            }
        }
    </script>
</body>
</html>