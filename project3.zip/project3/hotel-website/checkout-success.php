<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - M<sup>2</sup> Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php
    require_once 'php/db_connection.php';
    
    // Check if order was successful
    if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
        header("Location: index.php");
        exit;
    }
    
    $order_id = sanitizeInput($_GET['order_id']);
    ?>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <h1>M<sup>2</sup> Hotel</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About Us</a></li>
                <li><a href="menu.php">Menu</a></li>
                <li><a href="order.php">Order</a></li>
                <li><a href="gallery.php">Gallery</a></li>
                <li><a href="rooms.php">Rooms</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
            <div class="cart-icon-wrapper">
                <a href="cart.php" class="cart-icon" title="View Cart">
                    <span class="cart-symbol">🛒</span>
                    <span class="cart-count" id="cart-count">0</span>
                </a>
            </div>
            <div class="hamburger" id="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Success Message -->
    <div class="container">
        <div class="success-message">
            <div class="success-icon">✓</div>
            <h2>Order Confirmed!</h2>
            <p>Thank you for your order</p>
            <div class="order-details">
                <p>Your order reference: <strong><?php echo htmlspecialchars($order_id); ?></strong></p>
                <p>A confirmation email has been sent to your registered email address.</p>
                <p>Our team will contact you soon with delivery details.</p>
            </div>
            <div class="success-actions">
                <a href="index.php" class="btn btn-primary">Back to Home</a>
                <a href="menu.php" class="btn btn-secondary">Continue Shopping</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-section">
                <h4>M<sup>2</sup> Hotel</h4>
                <p>Your destination for fine dining and comfort.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="menu.php">Menu</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="cart.php">Shopping Cart</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact</h4>
                <p>Email: m2@info.rw</p>
                <p>Phone: +250 793 732 248</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 M<sup>2</sup> Hotel. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Clear cart after successful order
            localStorage.removeItem('cart');
            updateCartCount();
        });
    </script>
</body>
</html>
