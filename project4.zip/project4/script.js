// Static fallback currency conversion rates (relative to USD)
const staticExchangeRates = {
    USD: 1,
    EUR: 0.92,
    GBP: 0.79,
    JPY: 149.50,
    CAD: 1.36,
    FRW: 1290.00
};

// Live exchange rates (will be populated from API)
let liveExchangeRates = { ...staticExchangeRates };

// Get DOM elements
const amountInput = document.getElementById('amount');
const fromCurrencySelect = document.getElementById('fromCurrency');
const toCurrencySelect = document.getElementById('toCurrency');
const rateInput = document.getElementById('rate');
const convertBtn = document.getElementById('convertBtn');
const resultDisplay = document.getElementById('result');
const refreshBtn = document.getElementById('refreshBtn');

// Event listeners
convertBtn.addEventListener('click', performConversion);
refreshBtn.addEventListener('click', () => {
    fetchExchangeRates();
    resultDisplay.textContent = 'Rates updated!';
    resultDisplay.style.color = '#00ff00';
    setTimeout(() => {
        resultDisplay.textContent = 'Ready to convert';
    }, 2000);
});
amountInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') performConversion();
});

// Auto-update exchange rate when currency selection changes
fromCurrencySelect.addEventListener('change', updateExchangeRate);
toCurrencySelect.addEventListener('change', updateExchangeRate);

// Fetch real-time exchange rates from free API
async function fetchExchangeRates() {
    try {
        const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
        if (response.ok) {
            const data = await response.json();
            
            // Update rates from API
            for (let currency in staticExchangeRates) {
                if (data.rates[currency]) {
                    liveExchangeRates[currency] = data.rates[currency];
                }
            }
            
            // Update the display with new rates
            updateExchangeRate();
            const now = new Date().toLocaleTimeString();
            console.log(`Exchange rates updated from API at ${now}`);
        }
    } catch (error) {
        console.log('Using static exchange rates (API unavailable)');
        liveExchangeRates = { ...staticExchangeRates };
        updateExchangeRate();
    }
}

// Auto-refresh exchange rates every 5 minutes (300000 ms)
function startAutoRefresh() {
    setInterval(() => {
        fetchExchangeRates();
    }, 300000);
}

// Update exchange rate based on selected currencies
function updateExchangeRate() {
    const fromCurrency = fromCurrencySelect.value;
    const toCurrency = toCurrencySelect.value;

    if (fromCurrency && toCurrency && fromCurrency !== toCurrency) {
        const fromRate = liveExchangeRates[fromCurrency];
        const toRate = liveExchangeRates[toCurrency];
        const calculatedRate = (toRate / fromRate).toFixed(4);
        rateInput.value = calculatedRate;
    } else if (fromCurrency === toCurrency) {
        rateInput.value = '1.00';
    }
}

// Perform the currency conversion
function performConversion() {
    const amount = parseFloat(amountInput.value);
    const fromCurrency = fromCurrencySelect.value;
    const toCurrency = toCurrencySelect.value;
    const rate = parseFloat(rateInput.value);

    // Validation
    if (isNaN(amount) || amount < 0) {
        showError('Please enter a valid amount');
        return;
    }

    if (isNaN(rate) || rate <= 0) {
        showError('Please enter a valid exchange rate');
        return;
    }

    // Perform calculation
    const convertedAmount = (amount * rate).toFixed(2);
    const resultText = `${amount} ${fromCurrency} = ${convertedAmount} ${toCurrency}`;
    
    displayResult(resultText);
    console.log(`Converted: ${amount} ${fromCurrency} to ${toCurrency} at rate ${rate}`);
}

// Display result with success styling
function displayResult(text) {
    resultDisplay.textContent = text;
    resultDisplay.style.color = '#00ff00';
}

// Show error message
function showError(message) {
    resultDisplay.textContent = message;
    resultDisplay.style.color = '#ff6b6b';
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    // Fetch current exchange rates
    fetchExchangeRates();
    
    // Auto-refresh rates every 5 minutes
    startAutoRefresh();
    
    // Auto-convert when valid inputs are present
    amountInput.addEventListener('input', () => {
        if (amountInput.value && rateInput.value) {
            performConversion();
        }
    });
});
